# Litematica Material Task Assigner — 設計書 v0.2

> v0.2差分: オフラインプレイヤーも候補に含める方針を確定。sakura-ryokoフォークの実ソース（DeepWiki経由）を調査し §11 に反映。Mod名は独立namespaceで個人用として確定方針（§12）。

対象: Minecraft **1.21.11** / Fabric
前提Mod: MaLiLib, Litematica, Syncmatica, Servux（すべて **sakura-ryoko フォーク**、group id `fi.dy.masa` 維持）, Fabric API
将来: 1.12〜1.21.xの他バージョン対応は後回し。ただしバージョン非依存ロジックとMC依存ロジックは最初から分離しておく。

---

## 1. コンセプト

Syncmaticaで共有された設計図の **Material List** に対して、
- アイテムごとに「誰が担当するか」をサーバー上のプレイヤーへ割り振れる
- 割り振りUIはドロップダウン＋検索
- UUIDからプレイヤーヘッド（顔アイコン）を出してタブリストのように識別しやすくする
- 担当プレイヤーの**インベントリを鯖からリアルタイムに参照**して、必要数集まったら自動でチェックが付く
- チェックは手動でも切り替え可能

仮のMod名: **`mattask`**（Material Task の略。正式名は後で決めてOK）

---

## 2. 全体アーキテクチャ

Fabricの1Mod2ビルド構成（`common` / `client` / `server` を loom の環境で分離するのが理想だが、まずはシンプルに **1つのjarでclient/server両対応**にして `FabricLoader.getInstance().getEnvironmentType()` で分岐でも十分）。

```
mattask
├── common/            … 環境非依存（データモデル、シリアライズ、プロトコル定義）
│   ├── data/          MaterialTaskState, PlayerAssignment, ItemProgress
│   ├── network/        CustomPayload定義（S2C/C2S）
│   └── util/           ログユーティリティ
├── server/            … サーバー専用ロジック
│   ├── PlayerInventoryTracker   … tick監視 + diff配信
│   ├── PlayerDirectory          … オンライン/オフラインUUID一覧、オフラインNBT読み取り
│   ├── TaskStateStore            … 永続化（ファイルI/O）
│   └── SyncmaticaBridge (server) … セッション生成/破棄フック
└── client/            … クライアント専用ロジック
    ├── mixin/          Litematicaの MaterialListScreen 等へのMixin
    ├── gui/             ドロップダウン、検索ボックス、アイコン描画、チェックボックス
    ├── SkinIconCache    UUID→頭アイコン のキャッシュ
    └── SyncmaticaBridge (client) … 現在表示中の設計図＝どのSyncmaticaセッションかを取得
```

### なぜ独自プロトコルを新設するか
LitematicaとServuxは既に「Data Tag」という独自パケット圧縮システムを持っているが、これは彼らの内部実装であり外部Modが乗っかる想定のAPIではない（バージョン間で頻繁に破壊的変更が入っている実績あり＝リリースノートに"Hard network backwards compat breakage"と明記あり）。
→ **本Modは Fabric API の `PayloadTypeRegistry` / `CustomPayload` を使って完全に独立したチャンネルを持つ。** Litematica/Servux内部への依存はMixinでのUI差し込みとデータ読み取りのみに限定する。

---

## 3. データモデル（common）

```
MaterialTaskSession
├── schematicUid: String        … Syncmaticaのセッション/設計図ID
├── schematicName: String       … 表示用
├── items: List<ItemTask>
└── lastUpdated: long

ItemTask
├── itemKey: String             … "minecraft:oak_planks" (NBT差分がある場合はhash付与)
├── requiredCount: int
├── assignedPlayer: UUID?       … null = 未割当
├── manualCollected: boolean    … 手動チェック
└── autoCollectedCount: int     … 担当者インベントリから検出した保持数（キャッシュ）

# 「集まった」判定 = manualCollected == true OR autoCollectedCount >= requiredCount
```

サーバー側で保持するプレイヤー情報:
```
PlayerSnapshot
├── uuid: UUID
├── name: String
├── online: boolean
└── inventorySignature: long    … インベントリ内容のハッシュ（差分検知用、毎回全量送信を避ける）
```

---

## 4. ネットワークプロトコル（独自チャンネル）

すべて `mattask:xxx` の CustomPayload。1.21.x系のレコード式Payload APIを使用。

| 方向 | Payload | 内容 | 用途 |
|---|---|---|---|
| C→S | `RequestPlayerListC2S` | なし | プレイヤー一覧要求（プルダウン用） |
| S→C | `PlayerListS2C` | List<PlayerSnapshot> | オンライン＋既知オフラインプレイヤー一覧 |
| C→S | `RequestPlayerHeadC2S` | uuid | ヘッドアイコン用スキン要求（オフラインプレイヤー対策） |
| S→C | `PlayerHeadS2C` | uuid, base64 skin url or texture id | クライアント側でMinecraftSessionServiceに投げず鯖経由にすることで鯖外通信を減らす（後述4.1） |
| C→S | `AssignPlayerC2S` | schematicUid, itemKey, uuid or null | 割り当て変更 |
| C→S | `SetManualCheckC2S` | schematicUid, itemKey, boolean | 手動チェック変更 |
| S→C | `TaskStateSyncS2C` | MaterialTaskSession（全量 or 差分） | 割り当て・進捗の同期。同じ設計図を見ている全クライアントへブロードキャスト |
| S→C | `InventoryProgressS2C` | uuid, Map<itemKey,count> | 該当プレイヤーが担当しているアイテムの現在所持数のみ（全量ではなく関係アイテムだけ絞って送信＝帯域節約） |

### 4.1 スキン/アイコンの取得方針
- オンラインプレイヤー: クライアントは通常のPlayerListEntry経由でスキンを取れるので、そのまま `DrawableHelper`/`PlayerSkinDrawer` 的な仕組みで頭を描画すればOK（鯖側の関与不要）。
- オフラインプレイヤー（ログアウト中でも割り当てたい場合）: クライアント側でMojang Session Serverに直接問い合わせても良いが、鯖管理下のオフライン鯖(auth無効)だと使えないケースがあるため、**鯖側でUUID→テクスチャの解決をキャッシュして流す**方式を基本とし、取れなければ「?」アイコンにフォールバック。

---

## 5. サーバー側実装詳細

### 5.1 プレイヤー一覧（確定）
**「鯖に来たことがある全員」を候補に出す。** オンライン/オフライン問わずプルダウンに表示。
- オンライン: `server.getPlayerManager().getPlayerList()` からUUID/名前取得。`online: true`。
- オフライン: `usercache.json`（`<name, uuid, expiresOn>`の配列）を読み込んで一覧化。`online: false`。
  - `usercache.json` はサーバーrootにあるMojang由来のキャッシュで、鯖に一度でも接続したプレイヤーが載る。オフライン鯖(`online-mode=false`)でもここに載る名前解決は行われる（UUIDはオフラインUUID = `OfflinePlayer:name`のUUIDv3になる点に注意。オフライン鯖運用の場合は割り当てキーとしてこのUUIDをそのまま使えばOK）。
  - `world/playerdata/*.dat` は「そのプレイヤーが実際にワールドに入ったことがある」証跡として補助的に使う（usercacheだけだとログインコマンド等で載るケースもあるため、playerdataの存在確認で「実際にプレイした人」に絞ってもよい）。
- 一覧は起動時に一度読み込み＋新規ログイン時に追記更新（毎回全ファイルスキャンしない）。

### 5.2 インベントリのリアルタイム反映
- 目的アイテムに関係するプレイヤーのみ監視対象にする（全プレイヤー全アイテムを毎tick舐めるのは重い）。
- `ServerTickEvents.END_SERVER_TICK` で **N tick（例: 20tick=1秒）ごと**に、「現在何らかのアイテムを割り当てられているオンラインプレイヤー」だけ対象にインベントリをスキャンし、対象itemKeyの所持数を集計。
- 前回値とdiffがあれば `InventoryProgressS2C` を該当セッションの購読クライアントへ送信。
- オフラインプレイヤーは鯖起動中は再スキャンできない（NBT読み直しはできるが重い＆非推奨）ので、**オフライン中は最後に取得した値を「凍結」表示**にする。

### 5.3 Syncmaticaとの連携（サーバー側、§11.3で方針確定）
- Mixinで内部イベントを掴むのではなく、**`{worldFolder}/syncmatica/placements.json` を低頻度ポーリング（例: 30秒毎）して現在のUUID一覧を取得**する。
- 前回ポーリング時のUUID集合との差分を取り、新規UUID→ `MaterialTaskSession` の空データを用意、消失UUID→ `TaskStateStore` の該当ファイルを削除。
- JSONパース失敗時（スキーマ変更等）はエラーログを出すのみで機能を止めない（フェイルセーフ）。

---

## 6. クライアント側実装詳細

### 6.1 Litematica Material List UIへの差し込み
- LitematicaのMaterial List画面（想定クラス名は要ソース確認。旧maruohon版では `fi.dy.masa.litematica.gui.MaterialListScreen` 系＋ `MaterialListBase`/`MaterialListEntry` 相当）に対してMixinで:
  - 各行の右側に「担当者アイコン＋名前」「▼ドロップダウン」「チェックボックス」を追加描画
  - ドロップダウンは検索ボックス付きのカスタムWidget（新規実装、MaLiLibのGuiTextField等を流用）
- 開いている設計図がどのSyncmaticaセッションに対応するかは、サーバー側と同様に**クライアント側のSyncmaticaファイル（`./schematics/sync/`配下のキャッシュ）に対応付くUUIDを、鯖から配信される `PlayerListS2C`/`TaskStateSyncS2C` 等と突き合わせて特定**する方式にし、Syncmaticaクライアント内部クラスへの直接依存は避ける。

### 6.2 描画
- プレイヤーヘッドは `PlayerSkinDrawer`（1.21台の描画APIに準拠、要バージョン確認）でGUI内に16x16程度で描画。
- 検索ドロップダウンはプレイヤー名の部分一致でフィルタ。

---

## 7. 永続化設計

要件: 「鯖再起動で消えない」「ファイルがまとまってる」「共有終了で自動削除」「容量小さい」

**採用案: ワールドセーブ内 `world/data/mattask/<schematicUid>.json`（1設計図＝1ファイル）**

理由:
- `world/data/` はワールドと一緒に保存/バックアップされ、鯖再起動でも消えない。
- PersistentState(NBT埋め込み)より **JSONファイルの方が中身を目で見て確認できる＝デバッグしやすい**（正式リリース前の要件と合致）。
- 1設計図1ファイルなので「共有終了→該当ファイルをdeleteするだけ」で綺麗に消せる。
- 中身はitemKeyと担当UUID程度なので数KB～数十KB規模、容量問題なし。

保存タイミング: 割り当て変更/チェック変更のたび即書き込みではなく、**変更をダーティフラグで持ってserver tickの低頻度ループ（例: 10秒毎）でまとめて書き込み**＋鯖シャットダウン時に強制フラッシュ。

ファイル例:
```json
{
  "schematicUid": "syncmatica-session-abcdef",
  "schematicName": "castle_v3",
  "lastUpdated": 1730000000000,
  "items": [
    {
      "itemKey": "minecraft:oak_planks",
      "requiredCount": 640,
      "assignedPlayer": "b8f1e2b0-....",
      "manualCollected": false,
      "autoCollectedCount": 512
    }
  ]
}
```

---

## 8. ロギング設計（デバッグ用・正式リリース前提）

- 専用ロガー: `LogManager.getLogger("mattask")` とは別に、**独立したファイルAppenderを持つデバッグ専用ロガー**を用意（`log4j2.xml`をMod同梱、または`Configurator`でランタイム追加）。
- 出力先: `logs/mattask-debug.log`（RollingFileAppender、サイズ上限＋世代数を設定して肥大化防止）。
- config切り替え: `mattaskDebugLogging = true/false`（MaLiLib方式のconfigに乗せると他Modと統一感が出る）。
- ログ内容方針:
  - ネットワークパケット送受信（種類・サイズ・対象UUID）
  - Syncmaticaセッションのフック検知結果（見つかった/見つからなかった、を明示）
  - インベントリdiff検出のサマリ（毎tickではなく変化があった時だけ）
  - ファイルI/O（保存/削除のパス、成否）
- 形式は `[timestamp] [component] message` くらいの単純な行ベースでOK（構造化JSON化は今は過剰）。

---

## 9. 要確認・未確定事項（更新: v0.2時点）

1. ~~オフラインプレイヤーも割り当て候補に出すか~~ → **確定（§5.1）**。
2. ~~Syncmaticaのセッション/共有解除フック~~ → **調査完了（§11.2）**。ただし内部クラスへの直接依存は避け、**自前ファイル読み取り方式**を採用（理由は§11.3）。
3. ~~Litematica Material List画面の実クラス名~~ → **調査完了（§11.1）**。
4. NBTタグ付きアイテム（エンチャント本、名前付きアイテム等）をMaterial Listでどう区別してるか → `MaterialListBase`のエントリ生成ロジック（`GuiMaterialList`/`MaterialCache`周辺）を実際にコードレベルで読む必要あり。**Phase 0の残タスク**。
5. ~~Mod名・パッケージ~~ → **確定（§12）**。

---

## 10. 開発フェーズ案

| Phase | 内容 |
|---|---|
| 0 | 対象4Mod（sakura-ryokoフォーク）の実ソースを読み、§9の未確定事項を確定 |
| 1 | プロジェクト雛形（Fabric Loom, 1.21.11, MaLiLib/Litematica/Syncmatica/FabricAPIをdependencyに）＋ロギング基盤 |
| 2 | 独自ネットワークプロトコルの疎通確認（プレイヤー一覧を鯖→クライアントで取れるだけの最小実装） |
| 3 | Litematica Material List画面へのMixin差し込み（まずは静的にチェックボックスだけ追加） |
| 4 | ドロップダウン＋検索＋アイコン表示 |
| 5 | インベントリ監視＋自動チェック反映 |
| 6 | 永続化＋Syncmaticaセッション連動（作成/削除） |
| 7 | ロギング整理・デバッグ機能の作り込み・実運用テスト |

---

---

## 11. 実ソース調査結果（sakura-ryokoフォーク, DeepWiki経由で確認）

### 11.1 Litematica — Material List関連の実クラス（`fi.dy.masa.litematica` パッケージ）

| クラス | 役割 |
|---|---|
| `gui/GuiMaterialList.java` | Material List画面本体。ソート(`SortCriteria`: NAME/COUNT_TOTAL/COUNT_MISSING/COUNT_AVAILABLE)、multiplier機能、エクスポート機能を持つ |
| `gui/widgets/WidgetListMaterialList.java` | 一覧表示用の内部リストウィジェット（スクロール等） |
| `gui/widgets/WidgetMaterialListEntry.java` | **1行分のウィジェット。ここに担当者アイコン/ドロップダウン/チェックボックスをMixinで追加描画するのが本命ターゲット** |
| `materials/MaterialListHudRenderer.java` | GUIを開かなくても見れるHUD版。インベントリの中身をシュルカーボックス/バンドル含め再帰的にスキャンして所持数計算している（`materialListCountEnderCache`という設定でEnder Chest/Chest Trackerも見に行く仕組みが最近追加された＝アイテム所持数計算の参考実装になる） |
| `materials/MaterialCache` | ブロック→アイテムのマッピングキャッシュ |
| `DataManager` | 「最後に開いたMaterial List」等のUI状態を保持 |

→ Mixin対象は `WidgetMaterialListEntry` の描画メソッド（行の描画処理）と、`GuiMaterialList` の初期化処理（ヘッダー幅調整など）になりそう。実際のメソッドシグネチャはPhase 0で当該ファイルを1次ソースで直接読んで確定させる。

### 11.2 Syncmatica — セッション管理の実クラス（`ch.endte.syncmatica` パッケージ、**masa系ではなくEnd-Tech由来のnamespace**）

| クラス | 役割 |
|---|---|
| `data/SyncmaticManager.java` | **サーバー側**の共有設計図（`ServerPlacement`）管理の中心。`HashMap<UUID, ServerPlacement>`で保持。**UUID＝共有設計図の一意なID（＝設計書内の`schematicUid`はこれをそのまま使えばいい）** |
| ↳ `addServerPlacementConsumer(Consumer<ServerPlacement>)` / `removeServerPlacementConsumer(...)` | 追加/削除/更新時に通知を受け取れるConsumerパターンAPI（ただし外部Modに公開されたAPIではなく内部実装。アクセスにはMixinかリフレクションが要る） |
| `communication/ServerCommunicationManager.java` | 上記Managerのイベントを受けてクライアントへブロードキャストする層 |
| `Context.java` | DIコンテナ。`SyncmaticManager`/`FileStorage`/`CommunicationManager`等を保持。**サーバーの設定・データ保存場所は `{worldFolder}/syncmatica/` 配下**（`placements.json`, `placements.json.new`, `placements.json.bak`のatomic write方式） |

### 11.3 統合方針のアップデート（重要: バージョン変動への耐性設計）

ユーザー指摘の通り、sakura-ryokoフォークは**内部クラス構造の変更が頻繁**（Servuxのリリースノートに"Hard network backwards compat breakage"と明記されるレベル）。`SyncmaticManager`のConsumer APIのようなpublicメソッドであっても外部公開を意図したAPIではないため、Mixinで直接掴みにいくと **Litematica/Syncmaticaのマイナーバージョンが上がるたびに壊れるリスクが高い**。

→ **方針転換: Syncmaticaのセッション検知は「内部クラスへのMixin」ではなく「`{worldFolder}/syncmatica/placements.json` を自前で読み取るポーリング方式」を第一候補にする。**

理由:
- JSONファイルのスキーマは内部クラス構造よりも変更頻度が低い（外部ツールとの互換性のため比較的安定させる動機がある）。
- 読み取り専用なので、仮にスキーマが変わってパースに失敗しても「今回は同期スキップ」で済み、**クラッシュしない安全な劣化**ができる（ログにwarningを出すだけ）。
- 実装がシンプル（Mixin不要、ファイル監視 or 低頻度ポーリングのみ）。

このファイルにあるUUID一覧 = 「現在サーバー上で共有中の設計図一覧」として扱い、これが `mattask` 側の `world/data/mattask/<uuid>.json` の生存判定に使える（= placements.jsonから消えたUUIDのmattaskファイルを削除、という運用でSyncmaticaのバージョンに関わらず動く）。

Litematica側のMaterial List UI差し込み（`WidgetMaterialListEntry`）はUI描画なのでMixin必須だが、こちらは**「行を追加で描画するだけ」の非破壊的な差し込み**に留め、Litematica内部のデータ構造そのものを書き換えないようにする（読み取り専用参照＋自前のオーバーレイ）。これにより、Litematicaのアップデートで対象メソッドのシグネチャが変わっても「Mixin適用失敗→ログ出力→UI拡張だけ無効化（本体機能には影響なし）」というフェイルセーフができる。**Phase 1で実装する際、Mixinの`@Inject`は極力cancellable/オプショナルにし、失敗を握りつぶさずログに出す設計にする**（§8のロギング方針とも合致）。

---

## 12. Mod名・パッケージ（確定）

個人用・独立配布なので `fi.dy.masa` 系列やSyncmaticaの `ch.endte` には寄せず、**完全に独立したnamespace**にする。

- Mod ID: `mattask`（仮）
- パッケージ: `com.<yourname>.mattask` 形式で独立
- 依存Modへの言及は `fabric.mod.json` の `depends` にゆるく持たせる程度（バージョン範囲は緩め: 事故らないよう「動作確認したMC版」だけ明記し、Litematica/Syncmatica自体のバージョン固定はしない＝§11.3の疎結合方針と一貫）

---

次にやるべきは **Phase 0の残タスク**：実際に `WidgetMaterialListEntry.java` と `SyncmaticManager.java` の中身（メソッドシグネチャ、フィールド）を1次ソースで直接読んで、Mixin対象メソッド名とJSONスキーマの実物を確定させること。ここまで来ればPhase 1（プロジェクト雛形＋ロギング基盤）に入れる。
