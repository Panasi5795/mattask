# MatTask 引き継ぎメモ (2026-09-08時点)

Claude(このチャット)でのモバイルGitHub Actions往復開発から、Codespace上のOpenCodeへ引き継ぐにあたってのまとめ。

## 現在の状態

- **ビルド: 通っている。** GitHub Actionsで`gradle build`が成功し、実機(Android/AnviMC)で動作確認済み。
- **動いている機能:**
  - Modロード(client+server両方、singleplayer/専用サーバー両方で確認済み)
  - Litematica Material Listの各行に「担当: ○○」ボタンを実際に追加・描画
  - クリックで既知プレイヤー(usercache.json由来)を順番にサイクル割り当て
  - サーバー側: プレイヤー一覧の構築、`world/data/mattask/`への永続化基盤、Syncmaticaのplacements.json監視
  - 専用サーバー(AnviMC)でのプレイヤー一覧取得も確認済み(エラー0件)
- **まだできていない:**
  - 割り当てが**クライアントのメモリ上だけ**(`MattaskClient.localAssignments`という暫定Map)。サーバーへの送信(`AssignPlayerC2S`)は実装済みだが、ボタンのクリックハンドラからは**まだ呼んでいない**(ローカルサイクルのみ)。ここが次の最優先タスク。
  - 検索付きドロップダウンUI(今は「クリックで順番に切り替え」の仮実装)
  - チェックボックス(手動/自動収集判定)
  - インベントリのリアルタイム監視(`design.md` §5.2、未着手)
  - タスク状態の全クライアントへのブロードキャスト

## 直近直したバグ

ボタンを新規生成する際に常に「担当: 未割当」で初期化していて、`localAssignments`に既存の割り当てがあってもUIに反映されていなかった。`build.gradle`修正後の最新zipでは修正済み(初期化時に`localAssignments.get(itemKey)`を見るようにした)。**動作未確認**、Codespace側で最初にここを検証すること。

## ハマった罠と教訓(Mixin/Loom周り、超重要)

このプロジェクトのMixin実装で何度もコンパイル/実行時エラーを踏んだ。同じ轍を踏まないための記録:

1. **Mixinクラスに`extends <対象クラス自身>`を書いてはいけない。** `@Mixin(X.class)`のMixinクラスがXを継承しようとすると"Super class was not found in the hierarchy of target class"という実行時エラーで**Mixin自体の適用が丸ごと失敗する**(ただしrequire=0のフェイルセーフのおかげでクラッシュはしない、単に機能が無効化されるだけ)。

2. **`@Shadow`は継承元(親クラス)で宣言されているメソッド/フィールドを見つけられない。** `getX()`等がWidgetBase(数階層上の親)で定義されている場合、`@Shadow public abstract int getX();`と書いても"was not located in the target class"エラーになる。@Shadowは対象クラス自身に直接宣言されたメンバーしか見つけられない模様。

3. **上記2つの結果、採用した方針: extends/@Shadowを一切使わず、リフレクション(`getMethod`/`getDeclaredMethod`をクラス階層を遡りながら試す自作ヘルパー)で全部アクセスする。** `WidgetMaterialListEntryMixin.java`内の`mattask$findMethodInHierarchy` / `mattask$findFieldInHierarchy` / `mattask$invokeNoArg` / `mattask$invokeOneArg`がそのパターン。`Class#getMethod()`はpublicのみ(ただし継承元も検索する)、`getDeclaredMethod()`は全可視性(ただし対象クラス自身のみ)という非対称性があるため、両方をカバーするには階層を自分で歩く必要がある。

4. **`addButton`は`protected`だった。** `getMethod()`(publicのみ)では見つからず、`getDeclaredMethod()`を階層搜索するヘルパー経由で`setAccessible(true)`して呼ぶ必要があった。

5. **色指定でアルファチャンネルを忘れると完全に透明になる。** `0xAAAAAA`ではなく`0xFFAAAAAA`(先頭2桁が不透明度)が必要。描画コードが例外なく実行されているのに何も見えない場合、まずこれを疑う。

6. **依存関係はJitPackではなくModrinthの公式Maven経由。** `sakura-ryoko`フォーク(litematica/malilib/syncmatica/servux、1.21.11対応)をJitPackで取ろうとすると、内部の транзитив依存(`fi.dy.masa.malilib:...`等)が解決できず失敗する。Modrinthの`maven.modrinth:<projectId>:<versionId>`形式で個別取得するのが安定。座標は`build.gradle`にコメント付きで残してある。

7. **Fabric Loomのバージョンは`1.17.16`に固定。** 依存modごとに「もっと新しいLoomでビルドされてる」と言われて何度かバージョンを上げる羽目になった。`1.+`のような動的バージョン指定は要注意(alpha版を掴んでJava25要求されて詰んだことがある)。

8. **マッピングはYarn(`net.fabricmc:yarn:1.21.11+build.6:v2`)を使用。** 最初`officialMojangMappings()`で書いてしまい、クラス名(`PacketByteBuf`等のYarn名)が軒並み"cannot find symbol"になった。Mojang公式マッピングは別のクラス名体系(`FriendlyByteBuf`等)になるため注意。

9. **`com.mojang.authlib.GameProfile`は`getName()`ではなく`.name()`(レコード化されている)。**

10. **`onMouseClickedImpl`の引数型がYarnにまだ名前の付いていない`class_11909`という中間名クラスで、直接Java参照できなかった。** これが理由でクリック検出を自前実装するのを諦め、代わりにmalilibの`addButton()`(実在するボタン部品を追加する)方式に切り替えた。もし将来的にクリック位置を自前で判定する必要が出たら、この壁にまたぶつかる可能性がある。

## ビルド環境の注意

- このチャット(Claude)のサンドボックスは**ネットワークアクセスがない**ため、実際に`gradle build`を通す検証は一度もできていない。すべてGitHub Actions経由でのビルド確認になっている。Codespace環境ならネット直結なので、今後は`./gradlew build`的なコマンドで直接高速に試行錯誤できるはず。
- `.github/workflows/build.yml`にCI設定がある。プッシュのたびに自動ビルドされ、Artifactsにjarが上がる仕組み。Codespace移行後も併用可能。

## ファイル構成

```
mattask/
├── build.gradle, gradle.properties, settings.gradle
├── src/main/resources/fabric.mod.json, mattask.mixins.json, mattask.client.mixins.json
├── src/main/java/net/mattask/
│   ├── Mattask.java              共通初期化・サーバーtickループ・ネットワーク登録
│   ├── common/
│   │   ├── MattaskLog.java       専用デバッグログ(logs/mattask-debug.log)
│   │   ├── data/                 MaterialTaskSession, ItemTask, PlayerSnapshot
│   │   └── network/MattaskPayloads.java  独自ネットワークプロトコル定義
│   ├── server/
│   │   ├── PlayerDirectory.java         usercache.json読み込み+オンライン一覧
│   │   ├── TaskStateStore.java          world/data/mattask/への永続化
│   │   └── SyncmaticaPlacementWatcher.java  placements.jsonポーリング
│   └── client/
│       ├── MattaskClient.java           S2Cハンドラ、localAssignments(暫定)
│       └── mixin/WidgetMaterialListEntryMixin.java  Material List UI差し込み(本体)
docs/design.md                    元の設計書(v0.2、Phase 0-7の計画あり)
```

## 次の一手(優先順)

1. ボタン初期化バグ修正の動作確認
2. `mattask$onAssignButtonClicked`から実際に`MattaskClient.sendAssignPlayer(...)`を呼んでサーバーに送る(今はローカルmapを更新するだけ)
3. サーバー側`AssignPlayerC2S`受信時、`TASK_STATE_STORE`のどのセッション(`schematicUid`)に紐づけるか未実装(現状は決め打ちの`schematicUid`が無い状態でクリックしてもサーバー側で見つからず何も起きないはず)。Syncmaticaのセッションと紐づける部分(§11.3のポーリング機構)とMaterial List側のUIを繋ぐ設計がまだ空白。
4. 検索付きドロップダウンへの置き換え(今の「クリックでサイクル」は暫定)
5. 複数人での実地テスト
