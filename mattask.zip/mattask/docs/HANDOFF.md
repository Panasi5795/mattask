# MatTask 引き継ぎメモ (2026-09-10時点、新チャット継続用)

新しいチャットでこのプロジェクトを継続する際に、最初にこのファイルを読んでもらうためのもの。

## このプロジェクトの進め方(重要)

- 開発者はスマホのみで、PCなし。GitHubのモバイルWebブラウザ操作 + GitHub Actionsでのビルド確認、という往復サイクルで開発してきた。
- **Claudeのサンドボックスはネットワークアクセスがない**ため、Claude自身は`gradle build`を一度も実行できていない。コード修正→zip化→ユーザーがGitHubにアップロード→Actionsがビルド→ログをスクショで送ってもらう→Claudeが解析、のループ。
- リポジトリ: `https://github.com/Panasi5795/mattask` (詳細はユーザーに確認)
- 手順の型: 何か直したら (1) ローカルのzipを更新 (2) `present_files`で新しいzipを渡す (3) 「`mattask.zip`を削除して新しいのをアップロードして、Actionsの結果を教えて」と伝える。この定型パターンを継続すること。
- ビルドエラーのスクショが来たら、まずエラーメッセージを正確に読み、**勘で直さずリフレクションで実際の構造を調べてから直す**のがこのプロジェクトの基本方針(下記の教訓参照)。

## 現在の状態(2026-09-10時点)

- **ビルド: 通っている。** 実機(Android/AnviMC専用サーバー)で複数人でのリアルタイム同期・永続化まで動作確認済み。
- **動いている機能:**
  - Modロード(client+server、singleplayer/専用サーバー両方で確認済み、エラー0件)
  - Litematica Material Listの各行に**ドロップダウン(WidgetDropDownList、malilib純正部品)**を追加、プレイヤーを選択できる
  - 選択すると実際にサーバーへ送信(`AssignPlayerC2S`)され、`world/data/mattask/<設計図名>.json`に永続化される
  - サーバー再起動しても割り当てが復元される(確認済み)
  - 誰かが割り当てを変更すると、オンライン全員へブロードキャストされ、他プレイヤーの画面にもリアルタイムで反映される(確認済み)
  - オフラインプレイヤーも`usercache.json`経由で候補に出る(確認済み)
  - 「無視」ボタンとの位置重なりは、実際の幅を実測して回避する方式で解決済み(多言語環境でも自動対応)
- **直前に仕込んだが動作未確認の修正2つ**(このセッションの最後に修正、ビルド結果待ち):
  1. ドロップダウンの選択肢がプレイヤー一覧到着前に固定されてしまう問題 → 一覧が届くまで生成を遅延するよう修正
  2. 長いアイテム名(「白色の色付きガラス」等)がドロップダウンの上に重なって表示が壊れる問題 → ドロップダウンをTAILで強制再描画して最前面に出すよう修正
  - **次にやること: この2つの修正が実機で直っているか確認すること。**
- **まだ実装していない機能:**
  - プレイヤーヘッドアイコン表示(元の要望にあった「UUIDからIconを持ってきてタブリストのように」の部分。今は名前のみ)
  - チェックボックス(手動/自動収集判定)
  - インベントリのリアルタイム監視による自動チェック(design.md §5.2)
  - Syncmaticaの実UUIDとの紐付け(今は設計図名をキー代わりに使っている、詳細は下記)
  - 多言語対応の作り込み(英語で"Ignore"ボタンとの重なりを指摘されたが、UI方式を変える予定なので保留中)

## 設計上の意図的な妥協点

- **`schematicUid`は今のところ「設計図名」を使っている。** 本来はSyncmaticaのセッションUUIDと紐付けたかったが、調査コストが高いため後回しにした。データ層・通信層はどちらも`schematicUid`をただの文字列として扱っているだけなので、将来UUIDに差し替えるのは低コストな想定。同じ名前の設計図が複数あると衝突する点は既知の制約。
- サーバー側は`AssignPlayerC2S`受信時に「知らないセッション/アイテムなら自動作成」する設計にしてある(Syncmatica連携がまだ無いための対応)。

## ハマった罠と教訓(Mixin/Loom周り、超重要 — 新しいセッションでも必ず踏襲すること)

1. **Mixinクラスに`extends <対象クラス自身>`を書いてはいけない。** 自己参照エラーで"Super class was not found in the hierarchy of target class"となり、Mixin適用が丸ごと失敗する(require=0のフェイルセーフでクラッシュはしない)。

2. **`@Shadow`は継承元(親クラス)で宣言されているメソッド/フィールドを見つけられない。** 対象クラス自身に直接宣言されたメンバーしか見つけられない。

3. **上記の結果、採用した方針: extends/@Shadowを使わず、リフレクションで全部アクセスする。** `WidgetMaterialListEntryMixin.java`内の`mattask$findMethodInHierarchy` / `mattask$findFieldInHierarchy` / `mattask$invokeNoArg`がそのパターン。`getMethod()`はpublicのみだが継承元も検索、`getDeclaredMethod()`は全可視性だが対象クラス自身のみ、という非対称性があるため、階層を自分で歩く自作ヘルパーが必要。

4. **`addButton`/`addWidget`は`protected`。** `getMethod()`では見つからず、上記ヘルパー経由で`setAccessible(true)`して呼ぶ必要がある。

5. **色指定でアルファチャンネルを忘れると完全に透明になる。** `0xAAAAAA`ではなく`0xFFAAAAAA`が必要。描画コードが例外なく実行されてるのに何も見えない場合、まずこれを疑う。

6. **依存関係はJitPackではなくModrinthの公式Maven経由。** `sakura-ryoko`フォーク(litematica/malilib/syncmatica/servux、1.21.11対応)はJitPackだと内部の依存解決が失敗する。`maven.modrinth:<projectId>:<versionId>`形式で個別取得するのが安定。座標は`build.gradle`にコメント付きで残してある。

7. **Fabric Loomのバージョンは`1.17.16`に固定。** 依存modごとに要求Loomバージョンが違い、何度か上げる羽目になった。`1.+`のような動的指定はalpha版を掴んでJava25要求される事故があったので避ける。

8. **マッピングはYarn(`net.fabricmc:yarn:1.21.11+build.6:v2`)。** officialMojangMappings()だとYarn名(`PacketByteBuf`等)が軒並みcannot find symbolになる。

9. **`com.mojang.authlib.GameProfile`は`getName()`ではなく`.name()`(レコード化されている)。**

10. **`onMouseClickedImpl`の引数型がYarn未マッピングの`class_11909`という中間名クラスで、直接Java参照できなかった。** そのためクリック検出の自前実装は諦め、malilibの既存ウィジェット(`addButton`→後に`WidgetDropDownList`)を使う方針にした。ウィジェット自体が自分のクリック処理を内蔵しているので、この問題を回避できている。

11. **`addWidget()`で追加したサブウィジェットは、行自身のアイテム名テキストより「前」に描画される。** 長い名前のアイテムだとサブウィジェットの上に文字が被ってしまう。対策: TAILタイミングで該当ウィジェットの`render()`を明示的にもう一度呼んで、強制的に最前面に描画させる(このセッション最後の修正、動作未確認)。

12. **未知のmalilibウィジェット(`WidgetDropDownList`等)を使う前は、まず`Class.forName()`でクラス自体をリフレクション調査してからコードを書く。** 実インスタンスがなくてもクラスの静的情報(コンストラクタ・メソッド一覧)は起動時に調べられる。これで「勘で書いて外れる」を何度も防げた。

## ビルド環境の注意

- `.github/workflows/build.yml`にCI設定あり。プッシュのたびに自動ビルドされ、Actionsタブの該当ラン下部の「Artifacts」にjarが上がる。
- リポジトリ直下に`mattask.zip`という1ファイルを置く運用(GitHubのモバイルWebで複数ファイルのフォルダ構造アップロードが困難なため)。ワークフローが自動でunzipしてビルドする。
- 何かコードを直すたびに、ローカルの`/home/claude/mattask`ディレクトリを編集→zip化→ユーザーに渡す→ユーザーが既存の`mattask.zip`を削除して新しいものをアップロードし直す、という流れ。

## ファイル構成

```
mattask/
├── build.gradle, gradle.properties, settings.gradle
├── .github/workflows/build.yml   CI設定
├── src/main/resources/fabric.mod.json, mattask.mixins.json, mattask.client.mixins.json
├── src/main/java/net/mattask/
│   ├── Mattask.java              共通初期化・サーバーtickループ・ネットワーク登録・ブロードキャスト
│   ├── common/
│   │   ├── MattaskLog.java       専用デバッグログ(logs/mattask-debug.log)
│   │   ├── data/                 MaterialTaskSession, ItemTask, PlayerSnapshot
│   │   └── network/MattaskPayloads.java  独自ネットワークプロトコル定義(RequestTaskStateC2S等含む)
│   ├── server/
│   │   ├── PlayerDirectory.java         usercache.json読み込み+オンライン一覧
│   │   ├── TaskStateStore.java          world/data/mattask/への永続化、toJson()あり
│   │   └── SyncmaticaPlacementWatcher.java  placements.jsonポーリング(まだ実運用に繋がってない)
│   └── client/
│       ├── MattaskClient.java           S2Cハンドラ、localAssignments、applyTaskState()
│       └── mixin/WidgetMaterialListEntryMixin.java  Material List UI差し込み(本体、一番よく触るファイル)
docs/design.md                    元の設計書(v0.2、Phase 0-7の計画)
docs/HANDOFF.md                   このファイル
```

## 次の一手(優先順)

1. 直前の2つの修正(プレイヤー一覧待機、ドロップダウン強制再描画)が実機で直っているか確認
2. プレイヤーヘッドアイコンの表示(元の要望の一部、まだ未着手)
3. チェックボックス(手動収集判定)
4. インベントリ自動監視→自動チェック
5. 複数の設計図名が衝突するケースへの対処、またはSyncmatica実UUIDとの紐付け
