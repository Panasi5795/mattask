# MatTask (Phase 1 雛形)

Litematica Material Listにプレイヤー割り当て・進捗リアルタイム反映を追加するadditon mod。
対象: Minecraft 1.21.11 / Fabric / MaLiLib・Litematica・Syncmatica・Servux (sakura-ryokoフォーク)。

設計の全体像は `docs/design.md` を参照。

## 現状できていること (Phase 1〜2の一部)
- Gradle/Fabric Loomのプロジェクト雛形
- 専用デバッグログ `logs/mattask-debug.log`（config有効/無効切り替えは未実装、常時ON状態）
- 独自ネットワークプロトコル(mattask:xxx)の型定義と最小疎通コード
  - プレイヤー一覧要求→返却
  - 割り当て変更/手動チェック変更の受信(ブロードキャストはTODO)
- サーバー側: オンライン+オフライン(usercache.json)のプレイヤー一覧構築
- サーバー側: `world/data/mattask/<uuid>.json` への1設計図1ファイル永続化(ロード/保存/削除)
- サーバー側: Syncmaticaの `world/syncmatica/placements.json` を30秒毎にポーリングして
  共有中/共有終了を検知（**実スキーマ未検証、要調整**）
- クライアント側: S2Cペイロード受信の最小骨組み
- クライアント側: Litematica Material Listへの描画Mixin **スタブ**（実メソッドシグネチャ未検証）

## まだやってないこと
- Material List画面への実際のUI追加（アイコン/ドロップダウン/検索/チェックボックス描画）
- インベントリのリアルタイム監視・自動チェック反映
- タスク状態変更のブロードキャスト（今はサーバーが受信するだけ）
- config（デバッグログのON/OFF切り替え等）
- Syncmaticaのplacements.jsonの実スキーマ確認・調整

## ⚠️ 重要: このプロジェクトは未ビルド確認です

このコードは開発環境（サンドボックス、ネットワーク接続なし）で書かれたもので、
実際に `./gradlew build` を通してコンパイル確認をすることができていません。
特に以下は**そのままではビルドが通らない可能性が高い**箇所です:

1. `gradle.properties` の `malilib_version` — JitPackの実タグ名を
   https://github.com/sakura-ryoko/malilib/releases で確認して書き換える必要あり。
   litematica/syncmatica/servuxのタグも念のため最新のものに更新推奨。
2. `WidgetMaterialListEntryMixin.java` — Mixin対象メソッドのシグネチャが実際と
   違う可能性が高い（コメントに調べ方を書いてある）。
3. JitPack経由でのMod取得自体が初回ビルド時に時間がかかる/失敗することがある
   （JitPackがそのタグを初回ビルドする必要があるため）。

## ビルド手順（ネットワーク環境で）

```bash
./gradlew build
```

成功すれば `build/libs/mattask-<version>.jar` ができる。
失敗したら、エラーメッセージ（特にどのクラス/メソッドが見つからないと言っているか）を
そのまま教えてもらえれば、該当箇所を直す。

## 次のステップ (Phase 2以降)
docs/design.md の §10 開発フェーズ案を参照。
