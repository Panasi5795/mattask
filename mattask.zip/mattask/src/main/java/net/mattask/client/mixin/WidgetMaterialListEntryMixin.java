package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * (先頭にmalilibのGuiContextを取る4引数版だった。旧maruohon版の
 *  "render(int, int, boolean)" という3引数推測は外れていた。)
 *
 * フェイルセーフ方針(§11.3)は維持: mattask.client.mixins.json側で
 * required=false / defaultRequire=0 にしてあるので、今後また
 * シグネチャが変わってMixin適用が失敗しても、Litematica本体機能は壊れない。
 * その場合はまたログに 'Mixin apply for mod mattask failed ... Expected (...) but found (...)'
 * という形で正しいシグネチャがそのまま出るので、それに合わせて直せばよい。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        // 最小疎通確認用。実際の描画処理(アイコン/ドロップダウン/チェックボックス)は
        // Phase 3〜4でここに追加していく。
        MattaskLog.debug("WidgetMaterialListEntryMixin", "render TAIL hook fired (mixin applied successfully)");
    }
}
