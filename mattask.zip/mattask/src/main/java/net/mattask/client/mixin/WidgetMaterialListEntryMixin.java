package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * !!! Phase 0残タスク / 要検証 !!!
 *
 * design.md §11.1 の調査で、Material Listの1行を描画するクラスは
 * fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry だと確認できたが、
 * 実際の render メソッドのシグネチャ(引数の数・型)は1次ソースを直接読んで
 * 確定させる必要がある(DeepWikiの要約だけでは正確な引数列までは分からなかった)。
 *
 * このクラスは「ビルドが通ったら描画フックが刺さっていることをログで確認できる」
 * 最小のスタブとして書いてある。実際のアイコン/ドロップダウン/チェックボックス描画は
 * ここに追記していく(Phase 3〜4)。
 *
 * フェイルセーフ方針(§11.3): このMixinの適用自体が失敗しても
 * (対象メソッドが見つからない等) mattask.client.mixins.json 側で
 * required=false / defaultRequire=0 にしてあるので、Litematica本体機能は
 * 壊れない。適用に失敗した場合はゲーム起動時のログに
 * 'Mixin apply failed for WidgetMaterialListEntryMixin' 的な警告が出るはずなので、
 * それを見たらこのファイルのメソッド名/引数を実際のクラスに合わせて直すこと。
 *
 * 調べ方の一例:
 *   1. build.gradle の依存が解決された状態で
 *      ./gradlew genSources (Loomのタスク) を実行
 *   2. build/loom-cache 以下、または IDE (IntelliJ等) でこのクラスを
 *      逆コンパイル表示させて render 系メソッドの実シグネチャを確認
 *   3. 下の @Inject の method/target を実物に合わせて書き換える
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    // TODO: 実際のメソッド名・引数列を確認して書き換える。
    // 候補: render(int, int, boolean) / render(int, int, int, int, boolean) など
    // malilibのWidgetBase系は "public boolean render(int mouseX, int mouseY, boolean isActiveGui)"
    // のようなパターンが多い(旧maruohon版実績ベースの推測。sakura-ryokoフォークで
    // シグネチャが変わっている可能性がある)。
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        // 最小疎通確認用。実際の描画処理はここに追加していく。
        MattaskLog.debug("WidgetMaterialListEntryMixin", "render TAIL hook fired (mixin applied successfully)");
    }
}
