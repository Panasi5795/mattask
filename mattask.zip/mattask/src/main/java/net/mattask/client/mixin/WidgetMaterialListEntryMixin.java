package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * Phase 4準備: 実際にアイコン/ドロップダウン/チェックボックスを描画するには、
 * このウィジェットが内部に持っている「アイテム情報」「座標(x,y,width,height)」
 * 「必要数/所持数」などのフィールド名を正確に知る必要がある。
 * 前回render()の引数を勘で書いて外した反省を踏まえ、今回は勘で描画コードを
 * 書く前に、リフレクションで実際のフィールド/メソッド一覧をログに出力して
 * 確認する(1回だけ、§8のロギング方針に従う)。
 *
 * フェイルセーフ方針(§11.3)は維持: required=false / defaultRequire=0。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    private static boolean mattask$loggedOnce = false;
    private static int mattask$entryDumpCount = 0;
    private static final int MATTASK_MAX_ENTRY_DUMPS = 3;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        if (!mattask$loggedOnce) {
            mattask$loggedOnce = true;
            MattaskLog.info("WidgetMaterialListEntryMixin", "render hook confirmed working (this log only prints once per session)");
            mattask$dumpStructure();
        }

        // entryはrender呼び出し時点でまだ未セットのことがあるため、
        // 中身が入ったタイミングを最大3回まで捉えてMaterialListEntry自体の構造もダンプする
        Object entry = null;
        try {
            entry = ((fi.dy.masa.malilib.gui.widgets.WidgetListEntryBase) (Object) this).getEntry();
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "getEntry() failed", e);
        }

        if (mattask$entryDumpCount < MATTASK_MAX_ENTRY_DUMPS && entry != null) {
            mattask$entryDumpCount++;
            MattaskLog.info("WidgetMaterialListEntryDump", "entry #" + mattask$entryDumpCount + " runtime class = " + entry.getClass().getName());
            mattask$dumpObject(entry, "MaterialListEntry#" + mattask$entryDumpCount);
        }

        // Phase 4: 行の右端に「担当: ○○」のテキストを描画する(まずは見た目確認のみ、クリック操作は次段階)
        if (entry != null && entry.getClass().getName().equals("fi.dy.masa.litematica.materials.MaterialListEntry")) {
            try {
                String itemKey = mattask$readItemKey(entry);
                if (itemKey != null) {
                    String assignedName = net.mattask.client.MattaskClient.localAssignments.get(itemKey);
                    String label = "担当: " + (assignedName != null ? assignedName : "未割当");

                    int labelWidth = this.getStringWidth(label);
                    int drawX = this.getX() + this.getWidth() - labelWidth - 8;
                    int drawY = this.getY() + (this.getHeight() / 2) - 4;
                    int color = assignedName != null ? 0x55FF55 : 0xAAAAAA;

                    this.drawStringWithShadow(context, drawX, drawY, color, label);
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to draw assignment label", e);
            }
        }
    }

    /**
     * MaterialListEntry.item フィールドの可視性が不明(privateかもしれない)なため、
     * 直接アクセスせずリフレクション経由で安全に読む。取得できなければnullを返す
     * (呼び出し側は描画をスキップするだけでクラッシュしない)。
     */
    private String mattask$readItemKey(Object entry) {
        try {
            Field f = entry.getClass().getDeclaredField("item");
            f.setAccessible(true);
            Object item = f.get(entry);
            return item != null ? item.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$readItemKey failed", e);
            return null;
        }
    }

    private void mattask$dumpObject(Object target, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = target.getClass();
            sb.append("=== Field dump for ").append(label).append(" (").append(clazz.getName()).append(") ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(target);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 150) {
                                valueStr = valueStr.substring(0, 150) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "dumpObject failed for " + label, e);
        }
    }

    /**
     * Phase 4の設計材料集め用。このウィジェットのクラス階層にある
     * 全フィールド(自分自身のインスタンス値つき)と、全メソッド名/引数の型を
     * 1回だけログに出す。うまくいけば「itemStack」「count」「x」「y」
     * 「width」「height」的な名前のフィールドが見つかるはず。
     */
    private void mattask$dumpStructure() {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = this.getClass();

            // このMixinが適用された実クラス(WidgetMaterialListEntryの実装クラス)から
            // Objectまで、継承チェーンを全部辿ってフィールドを集める
            sb.append("=== Field dump for ").append(clazz.getName()).append(" and superclasses ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(this);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 120) {
                                valueStr = valueStr.substring(0, 120) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }

            sb.append("=== Method dump (names + param types only) ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }

            // ログファイルに複数行まとめて出す(1回きりなので肥大化の心配なし)
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "structure dump failed", e);
        }
    }
}
