package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * 重要な教訓その1(2026-09-07): Mixinクラスに "extends WidgetMaterialListEntry" は
 * 自己参照エラーになりNG。
 *
 * 重要な教訓その2(2026-09-07): @Shadow は「継承元(親クラス)で宣言されている
 * メソッド」までは見つけてくれない("No refMap loaded" + "was not located in
 * the target class" というエラーになる)。getX()/getY()/drawStringWithShadow()等は
 * WidgetMaterialListEntryの親クラス(WidgetBase)で定義されているため、
 * このケースでは@Shadowが使えなかった。
 *
 * → 対策: extends/@Shadowを一切使わず、Class#getMethod()ベースのリフレクションで
 * 呼び出す。getMethod()はJavaの仕様上、継承元の public メソッドも探してくれるため、
 * どの親クラスで定義されていても関係なく安定して呼び出せる
 * (Mixinの内部機構に依存しないので、Mixin/refmap周りの罠を丸ごと回避できる)。
 *
 * フェイルセーフ方針(§11.3)は維持: required=false / defaultRequire=0。
 * リフレクション呼び出しも全部try-catchで包み、失敗しても描画をスキップするだけ。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    private static boolean mattask$loggedOnce = false;
    private static boolean mattask$requestedTaskStateOnce = false;
    private static int mattask$entryDumpCount = 0;
    private static final int MATTASK_MAX_ENTRY_DUMPS = 3;

    /** このウィジェット(=行)インスタンスにつき1回だけボタンを追加するためのフラグ */
    private boolean mattask$buttonAdded = false;
    private String mattask$itemKey = null;
    private ButtonGeneric mattask$assignButton = null;
    private String mattask$lastKnownAssignment = null;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        if (!mattask$loggedOnce) {
            mattask$loggedOnce = true;
            MattaskLog.info("WidgetMaterialListEntryMixin", "render hook confirmed working (this log only prints once per session)");
            mattask$dumpStructure();
            // プレイヤー一覧をまだ持っていなければサーバーへ要求する
            net.mattask.client.MattaskClient.requestPlayerList();
        }

        // schematicUidは同じ開いているMaterial List内では共通なので、
        // プロセス全体で1回だけ計算してサーバーへ現在の割り当て状況を要求する。
        // (行ウィジェットごとに何度も送るのは無駄なので静的フラグでガードする)
        if (!mattask$requestedTaskStateOnce) {
            mattask$requestedTaskStateOnce = true;
            String schematicUid = mattask$getSchematicUid();
            if (schematicUid != null) {
                net.mattask.client.MattaskClient.requestTaskState(schematicUid);
                MattaskLog.debug("WidgetMaterialListEntryMixin", "requested task state for " + schematicUid);
            }
        }

        Object entry = mattask$invokeNoArg(this, "getEntry");

        if (mattask$entryDumpCount < MATTASK_MAX_ENTRY_DUMPS && entry != null) {
            mattask$entryDumpCount++;
            MattaskLog.info("WidgetMaterialListEntryDump", "entry #" + mattask$entryDumpCount + " runtime class = " + entry.getClass().getName());
            mattask$dumpObject(entry, "MaterialListEntry#" + mattask$entryDumpCount);
        }

        // Phase 4: 「担当」ボタンを1回だけ追加する(render()は毎フレーム呼ばれるが、
        // ボタン自体は行(=widgetインスタンス)につき1個でよいので、
        // インスタンスフィールドのフラグで多重追加を防ぐ)。
        if (!this.mattask$buttonAdded && entry != null
                && entry.getClass().getName().equals("fi.dy.masa.litematica.materials.MaterialListEntry")) {
            this.mattask$buttonAdded = true;
            try {
                String itemKey = mattask$readItemKey(entry);
                if (itemKey != null) {
                    this.mattask$itemKey = itemKey;
                    Integer x = (Integer) mattask$invokeNoArg(this, "getX");
                    Integer y = (Integer) mattask$invokeNoArg(this, "getY");
                    Integer width = (Integer) mattask$invokeNoArg(this, "getWidth");
                    Integer height = (Integer) mattask$invokeNoArg(this, "getHeight");

                    if (x != null && y != null && width != null && height != null) {
                        // 「無視」ボタン(x=708,y=49,width=28,height=20相当、行右端)と
                        // 重ならない位置に、幅90pxの「担当」ボタンを配置する
                        int buttonWidth = 90;
                        int buttonX = x + width - 28 - 8 - buttonWidth;
                        int buttonY = y;

                        String existingAssignment = net.mattask.client.MattaskClient.localAssignments.get(itemKey);
                        String initialLabel = "担当: " + (existingAssignment != null ? existingAssignment : "未割当");
                        this.mattask$lastKnownAssignment = existingAssignment;
                        ButtonGeneric assignButton = new ButtonGeneric(buttonX, buttonY, buttonWidth, height, initialLabel, new String[0]);
                        this.mattask$assignButton = assignButton;

                        String schematicUid = mattask$getSchematicUid();
                        IButtonActionListener listener = (button, mouseButton) -> {
                            mattask$onAssignButtonClicked(schematicUid, itemKey, assignButton);
                        };

                        Method addButtonMethod = mattask$findMethodInHierarchy(this.getClass(), "addButton", ButtonBase.class, IButtonActionListener.class);
                        if (addButtonMethod != null) {
                            addButtonMethod.setAccessible(true);
                            addButtonMethod.invoke(this, assignButton, listener);
                            MattaskLog.info("WidgetMaterialListEntryMixin", "assign button added for " + itemKey);
                        } else {
                            MattaskLog.warn("WidgetMaterialListEntryMixin", "addButton method not found in hierarchy");
                        }
                    }
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to add assign button", e);
            }
        }

        // 毎フレーム軽量チェック: サーバーからの同期(他プレイヤーの割り当て変更など)で
        // localAssignmentsが変わっていたら、既に表示済みのボタンのテキストも追従させる。
        // (ボタンを作り直すのではなく、テキストだけ書き換える単純な自己修復方式)
        if (this.mattask$buttonAdded && this.mattask$itemKey != null && this.mattask$assignButton != null) {
            String current = net.mattask.client.MattaskClient.localAssignments.get(this.mattask$itemKey);
            boolean changed = (current == null && this.mattask$lastKnownAssignment != null)
                    || (current != null && !current.equals(this.mattask$lastKnownAssignment));
            if (changed) {
                this.mattask$lastKnownAssignment = current;
                mattask$setButtonText(this.mattask$assignButton, "担当: " + (current != null ? current : "未割当"));
            }
        }
    }

    /**
     * 担当ボタンがクリックされた時の処理(Phase 4暫定版)。
     * まだドロップダウン+検索UIは作っていないので、
     * 「クリックするたびに既知プレイヤーを順番に切り替え、最後まで行ったら未割当に戻る」
     * という簡易サイクル方式で動作確認する。本格的なドロップダウンは次段階。
     */
    private void mattask$onAssignButtonClicked(String schematicUid, String itemKey, ButtonGeneric button) {
        try {
            java.util.List<net.mattask.common.data.PlayerSnapshot> players = net.mattask.client.MattaskClient.knownPlayers;
            String current = net.mattask.client.MattaskClient.localAssignments.get(itemKey);

            String next;
            java.util.UUID nextUuid = null;
            if (players.isEmpty()) {
                // まだサーバーからプレイヤー一覧を受け取れていない
                MattaskLog.warn("WidgetMaterialListEntryMixin", "no known players yet, cannot assign");
                return;
            } else if (current == null) {
                next = players.get(0).name;
                nextUuid = players.get(0).uuid;
            } else {
                int idx = -1;
                for (int i = 0; i < players.size(); i++) {
                    if (players.get(i).name.equals(current)) {
                        idx = i;
                        break;
                    }
                }
                if (idx < 0 || idx + 1 >= players.size()) {
                    next = null; // 一周したら未割当に戻す
                } else {
                    next = players.get(idx + 1).name;
                    nextUuid = players.get(idx + 1).uuid;
                }
            }

            if (next == null) {
                net.mattask.client.MattaskClient.localAssignments.remove(itemKey);
            } else {
                net.mattask.client.MattaskClient.localAssignments.put(itemKey, next);
            }

            String newLabel = "担当: " + (next != null ? next : "未割当");
            this.mattask$lastKnownAssignment = next;
            mattask$setButtonText(button, newLabel);

            // サーバーへ実際に送信する(schematicUidが取れなかった場合はローカル表示のみに留める)
            if (schematicUid != null) {
                net.mattask.client.MattaskClient.sendAssignPlayer(schematicUid, itemKey, nextUuid);
                MattaskLog.info("WidgetMaterialListEntryMixin", "assigned " + itemKey + " -> " + next + " (schematicUid=" + schematicUid + "), sent to server");
            } else {
                MattaskLog.warn("WidgetMaterialListEntryMixin", "schematicUid unavailable, assignment not sent to server (local UI only)");
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "onAssignButtonClicked failed", e);
        }
    }

    /** ButtonGenericの表示テキストをリフレクションで書き換える(setterの有無が未確認のため直接フィールドを触る)。 */
    private void mattask$setButtonText(ButtonGeneric button, String text) {
        try {
            Field f = mattask$findFieldInHierarchy(button.getClass(), "displayString");
            if (f != null) {
                f.setAccessible(true);
                f.set(button, text);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$setButtonText failed", e);
        }
    }

    /** 指定名・引数型のメソッドを、自クラスから親クラスへ順に遡って探す(protected/private含む)。見つからなければnull。 */
    private Method mattask$findMethodInHierarchy(Class<?> startClass, String name, Class<?>... paramTypes) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredMethod(name, paramTypes);
            } catch (NoSuchMethodException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /**
     * 「今開いてる設計図」を識別するキー(schematicUid代わり)を取得する。
     * 本来はSyncmaticaのセッションUUIDと紐付けたいが、その調査コストが高いため
     * 当面は MaterialListPlacement#getName() (設計図名)を代用する。
     * データ層・通信層はどちらもただの文字列キーとして扱っているため、
     * 将来Syncmaticaの実UUIDに差し替えるのは低コストな想定。
     */
    private String mattask$getSchematicUid() {
        try {
            Field materialListField = mattask$findFieldInHierarchy(this.getClass(), "materialList");
            if (materialListField == null) return null;
            materialListField.setAccessible(true);
            Object materialList = materialListField.get(this);
            if (materialList == null) return null;
            Object name = mattask$invokeNoArg(materialList, "getName");
            return name != null ? name.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$getSchematicUid failed", e);
            return null;
        }
    }

    /** 指定名のフィールドを、自クラスから親クラスへ順に遡って探す。見つからなければnull。 */
    private Field mattask$findFieldInHierarchy(Class<?> startClass, String fieldName) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** 引数なしのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeNoArg(Object target, String methodName) {
        try {
            Method m = target.getClass().getMethod(methodName);
            return m.invoke(target);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeNoArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /** 引数1つのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeOneArg(Object target, String methodName, Class<?> argType, Object arg) {
        try {
            Method m = target.getClass().getMethod(methodName, argType);
            return m.invoke(target, arg);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeOneArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /**
     * MaterialListEntry.item フィールドの可視性が不明(privateかもしれない)なため、
     * 直接アクセスせずリフレクション経由で安全に読む。取得できなければnullを返す。
     */
    private String mattask$readItemKey(Object entry) {
        try {
            Field f = entry.getClass().getDeclaredField("item");
            f.setAccessible(true);
            Object item = f.get(entry);
            return item != null ? item.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$readItemKey failed", e);
            return null;
        }
    }

    private void mattask$dumpObject(Object target, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = target.getClass();
            sb.append("=== Field dump for ").append(label).append(" (").append(clazz.getName()).append(") ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(target);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 150) {
                                valueStr = valueStr.substring(0, 150) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }
            sb.append("=== Method dump ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "dumpObject failed for " + label, e);
        }
    }

    /**
     * Phase 4の設計材料集め用。このウィジェットのクラス階層にある
     * 全フィールド(自分自身のインスタンス値つき)と、全メソッド名/引数の型を
     * 1回だけログに出す。
     */
    private void mattask$dumpStructure() {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = this.getClass();

            sb.append("=== Field dump for ").append(clazz.getName()).append(" and superclasses ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(this);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 120) {
                                valueStr = valueStr.substring(0, 120) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }

            sb.append("=== Method dump (names + param types only) ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }

            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "structure dump failed", e);
        }
    }
}
