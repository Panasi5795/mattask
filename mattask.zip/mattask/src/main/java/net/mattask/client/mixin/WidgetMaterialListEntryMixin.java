package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * 重要な教訓その1(2026-09-07): Mixinクラスに "extends WidgetMaterialListEntry" は
 * 自己参照エラーになりNG。
 *
 * 重要な教訓その2(2026-09-07): @Shadow は「継承元(親クラス)で宣言されている
 * メソッド」までは見つけてくれない("No refMap loaded" + "was not located in
 * the target class" というエラーになる)。getX()/getY()/drawStringWithShadow()等は
 * WidgetMaterialListEntryの親クラス(WidgetBase)で定義されているため、
 * このケースでは@Shadowが使えなかった。
 *
 * → 対策: extends/@Shadowを一切使わず、Class#getMethod()ベースのリフレクションで
 * 呼び出す。getMethod()はJavaの仕様上、継承元の public メソッドも探してくれるため、
 * どの親クラスで定義されていても関係なく安定して呼び出せる
 * (Mixinの内部機構に依存しないので、Mixin/refmap周りの罠を丸ごと回避できる)。
 *
 * フェイルセーフ方針(§11.3)は維持: required=false / defaultRequire=0。
 * リフレクション呼び出しも全部try-catchで包み、失敗しても描画をスキップするだけ。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    private static boolean mattask$loggedOnce = false;
    private static boolean mattask$loggedButtonOnce = false;
    private static int mattask$entryDumpCount = 0;
    private static final int MATTASK_MAX_ENTRY_DUMPS = 3;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        if (!mattask$loggedOnce) {
            mattask$loggedOnce = true;
            MattaskLog.info("WidgetMaterialListEntryMixin", "render hook confirmed working (this log only prints once per session)");
            mattask$dumpStructure();
        }

        Object entry = mattask$invokeNoArg(this, "getEntry");

        // Phase 4次段階(クリックで担当者割り当て)の下調べ。
        // onMouseClickedImplの引数型が未マッピングのクラスで直接扱えなかったため方針転換:
        // 既にMod自体が使っている「無視」ボタン(subWidgetsフィールド)を覗いて、
        // 同じ仕組み(addButton等)で自前ボタンを追加する方法を学ぶ。
        if (!mattask$loggedButtonOnce) {
            mattask$loggedButtonOnce = true;
            try {
                Field subWidgetsField = mattask$findFieldInHierarchy(this.getClass(), "subWidgets");
                if (subWidgetsField != null) {
                    subWidgetsField.setAccessible(true);
                    Object subWidgets = subWidgetsField.get(this);
                    MattaskLog.info("WidgetMaterialListEntryMixin", "subWidgets = " + subWidgets);
                    if (subWidgets instanceof java.util.List<?> list && !list.isEmpty()) {
                        Object existingButton = list.get(0);
                        MattaskLog.info("WidgetMaterialListEntryMixin", "existing button runtime class = " + existingButton.getClass().getName());
                        mattask$dumpObject(existingButton, "ExistingIgnoreButton");
                        // コンストラクタ一覧も見る(引数の型と数を知りたい)
                        for (var ctor : existingButton.getClass().getDeclaredConstructors()) {
                            StringBuilder params = new StringBuilder();
                            for (Class<?> p : ctor.getParameterTypes()) {
                                if (params.length() > 0) params.append(", ");
                                params.append(p.getSimpleName());
                            }
                            MattaskLog.info("WidgetMaterialListEntryDump", "constructor: (" + params + ")");
                        }
                    }
                } else {
                    MattaskLog.warn("WidgetMaterialListEntryMixin", "subWidgets field not found in hierarchy");
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "existing button inspection failed", e);
            }
        }

        if (mattask$entryDumpCount < MATTASK_MAX_ENTRY_DUMPS && entry != null) {
            mattask$entryDumpCount++;
            MattaskLog.info("WidgetMaterialListEntryDump", "entry #" + mattask$entryDumpCount + " runtime class = " + entry.getClass().getName());
            mattask$dumpObject(entry, "MaterialListEntry#" + mattask$entryDumpCount);
        }

        // Phase 4: 行の右端に「担当: ○○」のテキストを描画する(まずは見た目確認のみ、クリック操作は次段階)
        if (entry != null && entry.getClass().getName().equals("fi.dy.masa.litematica.materials.MaterialListEntry")) {
            try {
                String itemKey = mattask$readItemKey(entry);
                if (itemKey != null) {
                    String assignedName = net.mattask.client.MattaskClient.localAssignments.get(itemKey);
                    String label = "担当: " + (assignedName != null ? assignedName : "未割当");

                    Integer x = (Integer) mattask$invokeNoArg(this, "getX");
                    Integer y = (Integer) mattask$invokeNoArg(this, "getY");
                    Integer width = (Integer) mattask$invokeNoArg(this, "getWidth");
                    Integer height = (Integer) mattask$invokeNoArg(this, "getHeight");
                    Integer labelWidth = (Integer) mattask$invokeOneArg(this, "getStringWidth", String.class, label);

                    if (x != null && y != null && width != null && height != null && labelWidth != null) {
                        // 右端に既存の「無視」ボタンがあるため、それとの重なりを避けて
                        // さらに左にオフセットする(ボタン幅の実測値は未取得なので暫定値)
                        int drawX = x + width - labelWidth - 8 - 130;
                        int drawY = y + (height / 2) - 4;
                        int color = assignedName != null ? 0xFF55FF55 : 0xFFAAAAAA;

                        Method drawMethod = this.getClass().getMethod("drawStringWithShadow", GuiContext.class, int.class, int.class, int.class, String.class);
                        drawMethod.invoke(this, context, drawX, drawY, color, label);
                    }
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to draw assignment label", e);
            }
        }
    }

    /** 指定名のフィールドを、自クラスから親クラスへ順に遡って探す。見つからなければnull。 */
    private Field mattask$findFieldInHierarchy(Class<?> startClass, String fieldName) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** 引数なしのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeNoArg(Object target, String methodName) {
        try {
            Method m = target.getClass().getMethod(methodName);
            return m.invoke(target);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeNoArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /** 引数1つのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeOneArg(Object target, String methodName, Class<?> argType, Object arg) {
        try {
            Method m = target.getClass().getMethod(methodName, argType);
            return m.invoke(target, arg);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeOneArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /**
     * MaterialListEntry.item フィールドの可視性が不明(privateかもしれない)なため、
     * 直接アクセスせずリフレクション経由で安全に読む。取得できなければnullを返す。
     */
    private String mattask$readItemKey(Object entry) {
        try {
            Field f = entry.getClass().getDeclaredField("item");
            f.setAccessible(true);
            Object item = f.get(entry);
            return item != null ? item.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$readItemKey failed", e);
            return null;
        }
    }

    private void mattask$dumpObject(Object target, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = target.getClass();
            sb.append("=== Field dump for ").append(label).append(" (").append(clazz.getName()).append(") ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(target);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 150) {
                                valueStr = valueStr.substring(0, 150) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }
            sb.append("=== Method dump ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "dumpObject failed for " + label, e);
        }
    }

    /**
     * Phase 4の設計材料集め用。このウィジェットのクラス階層にある
     * 全フィールド(自分自身のインスタンス値つき)と、全メソッド名/引数の型を
     * 1回だけログに出す。
     */
    private void mattask$dumpStructure() {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = this.getClass();

            sb.append("=== Field dump for ").append(clazz.getName()).append(" and superclasses ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(this);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 120) {
                                valueStr = valueStr.substring(0, 120) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }

            sb.append("=== Method dump (names + param types only) ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }

            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "structure dump failed", e);
        }
    }
}
