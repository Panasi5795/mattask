package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * 重要な教訓その1(2026-09-07): Mixinクラスに "extends WidgetMaterialListEntry" は
 * 自己参照エラーになりNG。
 *
 * 重要な教訓その2(2026-09-07): @Shadow は「継承元(親クラス)で宣言されている
 * メソッド」までは見つけてくれない("No refMap loaded" + "was not located in
 * the target class" というエラーになる)。getX()/getY()/drawStringWithShadow()等は
 * WidgetMaterialListEntryの親クラス(WidgetBase)で定義されているため、
 * このケースでは@Shadowが使えなかった。
 *
 * → 対策: extends/@Shadowを一切使わず、Class#getMethod()ベースのリフレクションで
 * 呼び出す。getMethod()はJavaの仕様上、継承元の public メソッドも探してくれるため、
 * どの親クラスで定義されていても関係なく安定して呼び出せる
 * (Mixinの内部機構に依存しないので、Mixin/refmap周りの罠を丸ごと回避できる)。
 *
 * 重要な教訓その3(2026-09-12): 担当者選択に fi.dy.masa.malilib.gui.widgets.WidgetDropDownList
 * を使う実装は複数回のリフレクション調査を経ても不具合が解決しなかった
 * (maxHeight/maxVisibleEntries/isOpenまわりの内部挙動が特殊で、開いたパネルの
 * 位置・スクロール・選択のどれかが必ず壊れる)。深追いするコストが高いため撤退し、
 * このMixinだけで完結する自前描画+自前クリック検出方式に切り替えた。
 * クリック検出は onMouseClickedImpl(class_11909, boolean) にMixinで直接フックせず、
 * GLFWの生のマウスボタン状態を毎フレームポーリングする方式にしている
 * (class_11909はMinecraft側の内部クラスで、正しいYarn名も内部構造も未確認のため、
 * 変にMixinで触るより安全)。
 *
 * フェイルセーフ方針(§11.3)は維持: required=false / defaultRequire=0。
 * リフレクション呼び出しも全部try-catchで包み、失敗しても描画をスキップするだけ。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    private static boolean mattask$loggedOnce = false;
    private static int mattask$entryDumpCount = 0;
    private static final int MATTASK_MAX_ENTRY_DUMPS = 3;

    // プレイヤー一覧/タスク状態の要求リトライ用。
    // 実サーバー接続直後などはネットワークチャンネルがまだ確立しておらず
    // canSend()が一時的にfalseになることがあり、以前は「一度きり要求して終わり」
    // だったため、そのタイミングに当たると二度と再送されず、担当表示が
    // 永久に「未割当」のままになる不具合があった。
    // そのため、届く/送信成功するまで一定間隔でリトライするようにする。
    private static int mattask$frameCounter = 0;
    private static int mattask$lastPlayerListRequestFrame = Integer.MIN_VALUE / 2;
    private static int mattask$playerListRequestAttempts = 0;
    private static int mattask$lastTaskStateRequestFrame = Integer.MIN_VALUE / 2;
    private static int mattask$taskStateRequestAttempts = 0;
    private static final int MATTASK_RETRY_INTERVAL_FRAMES = 30; // だいたい0.5秒間隔(60fps想定)
    private static final int MATTASK_MAX_PLAYER_LIST_RETRIES = 20;
    private static final int MATTASK_MAX_TASK_STATE_RETRIES = 10;

    // マウス左ボタンの「前フレームの状態」。クリックの立ち上がり(押された瞬間)を
    // 自前で検出するために使う。マウスは1つしかないのでstatic(全行共有)でよい。
    private static boolean mattask$prevLeftMouseDown = false;

    /** このウィジェット(=行)インスタンスにつき1回だけ識別情報を確定するためのフラグ */
    private boolean mattask$assignmentReady = false;
    private String mattask$itemKey = null;
    private String mattask$schematicUid = null;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        mattask$frameCounter++;

        if (!mattask$loggedOnce) {
            mattask$loggedOnce = true;
            MattaskLog.info("WidgetMaterialListEntryMixin", "render hook confirmed working (this log only prints once per session)");
            mattask$dumpStructure();
        }

        // プレイヤー一覧がまだ届いていなければ、一定間隔でリトライしながら要求する。
        if (net.mattask.client.MattaskClient.knownPlayers.isEmpty()
                && mattask$playerListRequestAttempts < MATTASK_MAX_PLAYER_LIST_RETRIES
                && mattask$frameCounter - mattask$lastPlayerListRequestFrame >= MATTASK_RETRY_INTERVAL_FRAMES) {
            mattask$lastPlayerListRequestFrame = mattask$frameCounter;
            mattask$playerListRequestAttempts++;
            boolean sent = net.mattask.client.MattaskClient.requestPlayerList();
            MattaskLog.debug("WidgetMaterialListEntryMixin",
                    "requestPlayerList attempt " + mattask$playerListRequestAttempts + ", sent=" + sent);
            if (mattask$playerListRequestAttempts >= MATTASK_MAX_PLAYER_LIST_RETRIES
                    && net.mattask.client.MattaskClient.knownPlayers.isEmpty()) {
                MattaskLog.warn("WidgetMaterialListEntryMixin",
                        "giving up on player list request after " + mattask$playerListRequestAttempts + " attempts");
            }
        }

        // schematicUidは同じ開いているMaterial List内では共通なので、
        // プロセス全体で計算してサーバーへ現在の割り当て状況を要求する。
        if (mattask$taskStateRequestAttempts < MATTASK_MAX_TASK_STATE_RETRIES
                && mattask$frameCounter - mattask$lastTaskStateRequestFrame >= MATTASK_RETRY_INTERVAL_FRAMES) {
            String schematicUid = mattask$getSchematicUid();
            if (schematicUid != null) {
                mattask$lastTaskStateRequestFrame = mattask$frameCounter;
                mattask$taskStateRequestAttempts++;
                boolean sent = net.mattask.client.MattaskClient.requestTaskState(schematicUid);
                MattaskLog.debug("WidgetMaterialListEntryMixin",
                        "requestTaskState attempt " + mattask$taskStateRequestAttempts + " for " + schematicUid + ", sent=" + sent);
            }
        }

        Object entry = mattask$invokeNoArg(this, "getEntry");

        if (mattask$entryDumpCount < MATTASK_MAX_ENTRY_DUMPS && entry != null) {
            mattask$entryDumpCount++;
            MattaskLog.info("WidgetMaterialListEntryDump", "entry #" + mattask$entryDumpCount + " runtime class = " + entry.getClass().getName());
            mattask$dumpObject(entry, "MaterialListEntry#" + mattask$entryDumpCount);
        }

        // この行(=widgetインスタンス)につき1回だけ、アイテムキー等の識別情報を確定する。
        if (!this.mattask$assignmentReady && entry != null
                && entry.getClass().getName().equals("fi.dy.masa.litematica.materials.MaterialListEntry")) {
            try {
                String itemKey = mattask$readItemKey(entry);
                if (itemKey != null) {
                    this.mattask$itemKey = itemKey;
                    this.mattask$schematicUid = mattask$getSchematicUid();
                    this.mattask$assignmentReady = true;
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to initialize assignment cell", e);
            }
        }

        // 担当者表示セルの描画とクリック検出。
        // WidgetDropDownListを使わず、このMixinだけで完結させる(教訓その3参照)。
        if (this.mattask$assignmentReady && this.mattask$itemKey != null) {
            try {
                Integer x = (Integer) mattask$invokeNoArg(this, "getX");
                Integer y = (Integer) mattask$invokeNoArg(this, "getY");
                Integer width = (Integer) mattask$invokeNoArg(this, "getWidth");
                Integer height = (Integer) mattask$invokeNoArg(this, "getHeight");

                if (x != null && y != null && width != null && height != null) {
                    // 「無視」ボタンの実際の幅を実測し、それに合わせて重ならない位置に配置する
                    int ignoreButtonWidth = mattask$getIgnoreButtonWidth();
                    int cellWidth = 90;
                    int cellX = x + width - ignoreButtonWidth - 8 - cellWidth;
                    int cellY = y;
                    int cellHeight = height;

                    String assigned = net.mattask.client.MattaskClient.localAssignments.get(this.mattask$itemKey);
                    String displayName = assigned != null ? assigned : "未割当";

                    boolean hovering = mouseX >= cellX && mouseX < cellX + cellWidth
                            && mouseY >= cellY && mouseY < cellY + cellHeight;

                    // マウス左ボタンが「今フレームで新たに押された」かどうかを自前で判定する。
                    boolean leftDownNow = mattask$isLeftMouseButtonDown();
                    boolean justClicked = leftDownNow && !mattask$prevLeftMouseDown;
                    mattask$prevLeftMouseDown = leftDownNow;

                    if (justClicked && hovering) {
                        mattask$cycleAssignment(this.mattask$schematicUid, this.mattask$itemKey, assigned);
                    }

                    // ひとまずテキストのみの簡易表示(顔アイコンは別対応で追加予定)。
                    String label = "[" + displayName + "]";
                    int textColor = hovering ? 0xFFFFFF55 : 0xFFFFFFFF;
                    mattask$drawStringWithShadow(context, cellX + 2, cellY + Math.max(0, (cellHeight - 8) / 2), textColor, label);
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to render/handle assignment cell", e);
            }
        }
    }

    /** 現在の割り当てから次の候補(未割当 → プレイヤー1 → プレイヤー2 → ... → 未割当)へ切り替え、サーバーへ送信する。 */
    private void mattask$cycleAssignment(String schematicUid, String itemKey, String currentAssignment) {
        try {
            List<String> options = new ArrayList<>();
            options.add(null); // null = 未割当
            for (net.mattask.common.data.PlayerSnapshot p : net.mattask.client.MattaskClient.knownPlayers) {
                options.add(p.name);
            }

            int idx = options.indexOf(currentAssignment);
            int nextIdx = (idx + 1) % options.size();
            String next = options.get(nextIdx);

            java.util.UUID uuid = null;
            if (next != null) {
                for (net.mattask.common.data.PlayerSnapshot p : net.mattask.client.MattaskClient.knownPlayers) {
                    if (p.name.equals(next)) {
                        uuid = p.uuid;
                        break;
                    }
                }
            }

            if (next == null) {
                net.mattask.client.MattaskClient.localAssignments.remove(itemKey);
            } else {
                net.mattask.client.MattaskClient.localAssignments.put(itemKey, next);
            }

            if (schematicUid != null) {
                net.mattask.client.MattaskClient.sendAssignPlayer(schematicUid, itemKey, uuid);
                MattaskLog.info("WidgetMaterialListEntryMixin", "assigned " + itemKey + " -> " + next + " (schematicUid=" + schematicUid + "), sent to server");
            } else {
                MattaskLog.warn("WidgetMaterialListEntryMixin", "schematicUid unavailable, assignment not sent to server (local UI only)");
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "cycleAssignment failed", e);
        }
    }

    /** GLFWの生のマウスボタン状態を直接見る。Minecraft側のマッピング(class_11909等)に依存しないための対策。 */
    private boolean mattask$isLeftMouseButtonDown() {
        try {
            long handle = net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle();
            return GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "isLeftMouseButtonDown failed", e);
            return false;
        }
    }

    /** WidgetBaseの drawStringWithShadow(GuiContext, int, int, int, String) を実機ログで確認済みのシグネチャでリフレクション呼び出しする。 */
    private void mattask$drawStringWithShadow(GuiContext context, int x, int y, int color, String text) {
        try {
            Method m = mattask$findMethodInHierarchy(this.getClass(), "drawStringWithShadow",
                    GuiContext.class, int.class, int.class, int.class, String.class);
            if (m != null) {
                m.setAccessible(true);
                m.invoke(this, context, x, y, color, text);
            } else {
                MattaskLog.warn("WidgetMaterialListEntryMixin", "drawStringWithShadow method not found");
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "drawStringWithShadow failed", e);
        }
    }

    /**
     * 既存の「無視」ボタン(subWidgetsの最初の要素)の幅を取得する。
     * 言語設定によってボタン幅が変わる(日本語/中国語は短い文字、英語の"Ignore"は長い)ため、
     * 固定値で決め打ちせずその都度実測することで、どの言語でも重ならないようにする。
     * 取得できなければフォールバック値(28px、日本語想定)を返す。
     */
    private int mattask$getIgnoreButtonWidth() {
        try {
            Field subWidgetsField = mattask$findFieldInHierarchy(this.getClass(), "subWidgets");
            if (subWidgetsField != null) {
                subWidgetsField.setAccessible(true);
                Object subWidgets = subWidgetsField.get(this);
                if (subWidgets instanceof java.util.List<?> list && !list.isEmpty()) {
                    Object existingButton = list.get(0);
                    Integer w = (Integer) mattask$invokeNoArg(existingButton, "getWidth");
                    if (w != null && w > 0) {
                        return w;
                    }
                }
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$getIgnoreButtonWidth failed", e);
        }
        return 28; // フォールバック(日本語/中国語想定)
    }

    /** 指定名・引数型のメソッドを、自クラスから親クラスへ順に遡って探す(protected/private含む)。見つからなければnull。 */
    private Method mattask$findMethodInHierarchy(Class<?> startClass, String name, Class<?>... paramTypes) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredMethod(name, paramTypes);
            } catch (NoSuchMethodException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /**
     * 「今開いてる設計図」を識別するキー(schematicUid代わり)を取得する。
     * 本来はSyncmaticaのセッションUUIDと紐付けたいが、その調査コストが高いため
     * 当面は MaterialListPlacement#getName() (設計図名)を代用する。
     * データ層・通信層はどちらもただの文字列キーとして扱っているため、
     * 将来Syncmaticaの実UUIDに差し替えるのは低コストな想定。
     */
    private String mattask$getSchematicUid() {
        try {
            Field materialListField = mattask$findFieldInHierarchy(this.getClass(), "materialList");
            if (materialListField == null) return null;
            materialListField.setAccessible(true);
            Object materialList = materialListField.get(this);
            if (materialList == null) return null;
            Object name = mattask$invokeNoArg(materialList, "getName");
            return name != null ? name.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$getSchematicUid failed", e);
            return null;
        }
    }

    /** 指定名のフィールドを、自クラスから親クラスへ順に遡って探す。見つからなければnull。 */
    private Field mattask$findFieldInHierarchy(Class<?> startClass, String fieldName) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** 引数なしのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeNoArg(Object target, String methodName) {
        try {
            Method m = target.getClass().getMethod(methodName);
            return m.invoke(target);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeNoArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /**
     * MaterialListEntry.item フィールドの可視性が不明(privateかもしれない)なため、
     * 直接アクセスせずリフレクション経由で安全に読む。取得できなければnullを返す。
     */
    private String mattask$readItemKey(Object entry) {
        try {
            Field f = entry.getClass().getDeclaredField("item");
            f.setAccessible(true);
            Object item = f.get(entry);
            return item != null ? item.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$readItemKey failed", e);
            return null;
        }
    }

    private void mattask$dumpObject(Object target, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = target.getClass();
            sb.append("=== Field dump for ").append(label).append(" (").append(clazz.getName()).append(") ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(target);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 150) {
                                valueStr = valueStr.substring(0, 150) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }
            sb.append("=== Method dump ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "dumpObject failed for " + label, e);
        }
    }

    /**
     * Phase 4の設計材料集め用。このウィジェットのクラス階層にある
     * 全フィールド(自分自身のインスタンス値つき)と、全メソッド名/引数の型を
     * 1回だけログに出す。
     */
    private void mattask$dumpStructure() {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = this.getClass();

            sb.append("=== Field dump for ").append(clazz.getName()).append(" and superclasses ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(this);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 120) {
                                valueStr = valueStr.substring(0, 120) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }

            sb.append("=== Method dump (names + param types only) ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }

            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "structure dump failed", e);
        }
    }
}
