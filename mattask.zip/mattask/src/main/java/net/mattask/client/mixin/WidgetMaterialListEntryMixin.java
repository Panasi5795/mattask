package net.mattask.client.mixin;

import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.gui.widgets.WidgetBase;
import fi.dy.masa.malilib.gui.widgets.WidgetDropDownList;
import fi.dy.masa.malilib.render.GuiContext;
import net.mattask.common.MattaskLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * 実機ログで実シグネチャが確定した(2026-09-06):
 *
 *   render(GuiContext, int, int, boolean)
 *
 * 重要な教訓その1(2026-09-07): Mixinクラスに "extends WidgetMaterialListEntry" は
 * 自己参照エラーになりNG。
 *
 * 重要な教訓その2(2026-09-07): @Shadow は「継承元(親クラス)で宣言されている
 * メソッド」までは見つけてくれない("No refMap loaded" + "was not located in
 * the target class" というエラーになる)。getX()/getY()/drawStringWithShadow()等は
 * WidgetMaterialListEntryの親クラス(WidgetBase)で定義されているため、
 * このケースでは@Shadowが使えなかった。
 *
 * → 対策: extends/@Shadowを一切使わず、Class#getMethod()ベースのリフレクションで
 * 呼び出す。getMethod()はJavaの仕様上、継承元の public メソッドも探してくれるため、
 * どの親クラスで定義されていても関係なく安定して呼び出せる
 * (Mixinの内部機構に依存しないので、Mixin/refmap周りの罠を丸ごと回避できる)。
 *
 * フェイルセーフ方針(§11.3)は維持: required=false / defaultRequire=0。
 * リフレクション呼び出しも全部try-catchで包み、失敗しても描画をスキップするだけ。
 */
@Mixin(WidgetMaterialListEntry.class)
public abstract class WidgetMaterialListEntryMixin {

    private static boolean mattask$loggedOnce = false;
    private static boolean mattask$requestedTaskStateOnce = false;
    private static int mattask$entryDumpCount = 0;
    private static final int MATTASK_MAX_ENTRY_DUMPS = 3;

    /** このウィジェット(=行)インスタンスにつき1回だけドロップダウンを追加するためのフラグ */
    private boolean mattask$buttonAdded = false;
    private String mattask$itemKey = null;
    private String mattask$schematicUid = null;
    private WidgetDropDownList mattask$dropdown = null;
    private String mattask$lastKnownAssignment = null;
    private String mattask$lastUiSelection = null;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void mattask$onRenderTail(GuiContext context, int mouseX, int mouseY, boolean selected, CallbackInfo ci) {
        if (!mattask$loggedOnce) {
            mattask$loggedOnce = true;
            MattaskLog.info("WidgetMaterialListEntryMixin", "render hook confirmed working (this log only prints once per session)");
            mattask$dumpStructure();
            // プレイヤー一覧をまだ持っていなければサーバーへ要求する
            net.mattask.client.MattaskClient.requestPlayerList();
        }

        // schematicUidは同じ開いているMaterial List内では共通なので、
        // プロセス全体で1回だけ計算してサーバーへ現在の割り当て状況を要求する。
        // (行ウィジェットごとに何度も送るのは無駄なので静的フラグでガードする)
        if (!mattask$requestedTaskStateOnce) {
            mattask$requestedTaskStateOnce = true;
            String schematicUid = mattask$getSchematicUid();
            if (schematicUid != null) {
                net.mattask.client.MattaskClient.requestTaskState(schematicUid);
                MattaskLog.debug("WidgetMaterialListEntryMixin", "requested task state for " + schematicUid);
            }
        }

        Object entry = mattask$invokeNoArg(this, "getEntry");

        if (mattask$entryDumpCount < MATTASK_MAX_ENTRY_DUMPS && entry != null) {
            mattask$entryDumpCount++;
            MattaskLog.info("WidgetMaterialListEntryDump", "entry #" + mattask$entryDumpCount + " runtime class = " + entry.getClass().getName());
            mattask$dumpObject(entry, "MaterialListEntry#" + mattask$entryDumpCount);
        }

        // Phase 4: 「担当」ボタンを1回だけ追加する(render()は毎フレーム呼ばれるが、
        // ボタン自体は行(=widgetインスタンス)につき1個でよいので、
        // インスタンスフィールドのフラグで多重追加を防ぐ)。
        if (!this.mattask$buttonAdded && entry != null
                && entry.getClass().getName().equals("fi.dy.masa.litematica.materials.MaterialListEntry")) {
            this.mattask$buttonAdded = true;
            try {
                String itemKey = mattask$readItemKey(entry);
                if (itemKey != null) {
                    this.mattask$itemKey = itemKey;
                    Integer x = (Integer) mattask$invokeNoArg(this, "getX");
                    Integer y = (Integer) mattask$invokeNoArg(this, "getY");
                    Integer width = (Integer) mattask$invokeNoArg(this, "getWidth");
                    Integer height = (Integer) mattask$invokeNoArg(this, "getHeight");

                    if (x != null && y != null && width != null && height != null) {
                        // 「無視」ボタンの実際の幅を実測し、それに合わせて重ならない位置に配置する
                        // (言語設定でボタン幅が変わるため、固定値の決め打ちをやめた)
                        int ignoreButtonWidth = mattask$getIgnoreButtonWidth();
                        int dropdownWidth = 90;
                        int dropdownX = x + width - ignoreButtonWidth - 8 - dropdownWidth;
                        int dropdownY = y;

                        String schematicUid = mattask$getSchematicUid();
                        this.mattask$schematicUid = schematicUid;

                        // 選択肢: "未割当" + サーバーから取得済みの既知プレイヤー名一覧
                        List<String> options = new ArrayList<>();
                        options.add("未割当");
                        for (net.mattask.common.data.PlayerSnapshot p : net.mattask.client.MattaskClient.knownPlayers) {
                            options.add(p.name);
                        }

                        String existingAssignment = net.mattask.client.MattaskClient.localAssignments.get(itemKey);
                        this.mattask$lastKnownAssignment = existingAssignment;
                        this.mattask$lastUiSelection = existingAssignment != null ? existingAssignment : "未割当";

                        // コンストラクタ引数の意味は実機ログで確認した(int,int,int,int,int,int,List)の並び。
                        // (x, y, width, 1エントリの高さ, 開いた時の最大表示件数, zLevel, 選択肢一覧)と推測して使用。
                        WidgetDropDownList dropdown = new WidgetDropDownList(
                                dropdownX, dropdownY, dropdownWidth, height, 6, 0, options);
                        dropdown.setSelectedEntry(existingAssignment != null ? existingAssignment : "未割当");
                        this.mattask$dropdown = dropdown;

                        Method addWidgetMethod = mattask$findMethodInHierarchy(this.getClass(), "addWidget", WidgetBase.class);
                        if (addWidgetMethod != null) {
                            addWidgetMethod.setAccessible(true);
                            addWidgetMethod.invoke(this, dropdown);
                            MattaskLog.info("WidgetMaterialListEntryMixin", "assign dropdown added for " + itemKey);
                        } else {
                            MattaskLog.warn("WidgetMaterialListEntryMixin", "addWidget method not found in hierarchy");
                        }
                    }
                }
            } catch (Exception e) {
                MattaskLog.error("WidgetMaterialListEntryMixin", "failed to add assign button", e);
            }
        }

        // 毎フレームチェック: ドロップダウンの選択状態とサーバー側の実際の割り当てを突き合わせる。
        // - ユーザーがドロップダウンを操作した(UI側が前フレームと変わった) -> サーバーへ送信する
        // - サーバー側(他プレイヤーの操作等)で値が変わった(UIはまだ古いまま) -> ドロップダウンの表示だけ更新する
        // の2パターンを区別するため、UI側の前回値とサーバー側の前回値を別々にキャッシュしている。
        if (this.mattask$buttonAdded && this.mattask$itemKey != null && this.mattask$dropdown != null) {
            Object selectedObj = this.mattask$dropdown.getSelectedEntry();
            String uiSelection = selectedObj != null ? selectedObj.toString() : "未割当";

            if (!uiSelection.equals(this.mattask$lastUiSelection)) {
                // ユーザーがドロップダウンを操作した
                this.mattask$lastUiSelection = uiSelection;
                mattask$onDropdownSelectionChanged(this.mattask$schematicUid, this.mattask$itemKey, uiSelection);
            } else {
                String serverValue = net.mattask.client.MattaskClient.localAssignments.get(this.mattask$itemKey);
                String serverDisplay = serverValue != null ? serverValue : "未割当";
                if (!serverDisplay.equals(this.mattask$lastKnownAssignment)) {
                    // サーバー側(他プレイヤーの操作等)で変わった。UIだけ追従させる。
                    this.mattask$lastKnownAssignment = serverValue;
                    this.mattask$lastUiSelection = serverDisplay;
                    this.mattask$dropdown.setSelectedEntry(serverDisplay);
                }
            }
        }
    }

    /**
     * ドロップダウンの選択が変わった時の処理。
     * 選択された文字列からプレイヤーUUIDを逆引きし、サーバーへ送信する。
     */
    private void mattask$onDropdownSelectionChanged(String schematicUid, String itemKey, String selectedName) {
        try {
            java.util.UUID uuid = null;
            String normalized = null;
            if (!"未割当".equals(selectedName)) {
                for (net.mattask.common.data.PlayerSnapshot p : net.mattask.client.MattaskClient.knownPlayers) {
                    if (p.name.equals(selectedName)) {
                        uuid = p.uuid;
                        normalized = p.name;
                        break;
                    }
                }
            }

            if (normalized == null) {
                net.mattask.client.MattaskClient.localAssignments.remove(itemKey);
            } else {
                net.mattask.client.MattaskClient.localAssignments.put(itemKey, normalized);
            }
            this.mattask$lastKnownAssignment = normalized;

            if (schematicUid != null) {
                net.mattask.client.MattaskClient.sendAssignPlayer(schematicUid, itemKey, uuid);
                MattaskLog.info("WidgetMaterialListEntryMixin", "assigned " + itemKey + " -> " + normalized + " (schematicUid=" + schematicUid + "), sent to server");
            } else {
                MattaskLog.warn("WidgetMaterialListEntryMixin", "schematicUid unavailable, assignment not sent to server (local UI only)");
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "onDropdownSelectionChanged failed", e);
        }
    }

    /** ButtonGenericの表示テキストをリフレクションで書き換える(setterの有無が未確認のため直接フィールドを触る)。 */
    private void mattask$setButtonText(ButtonGeneric button, String text) {
        try {
            Field f = mattask$findFieldInHierarchy(button.getClass(), "displayString");
            if (f != null) {
                f.setAccessible(true);
                f.set(button, text);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$setButtonText failed", e);
        }
    }

    /**
     * 既存の「無視」ボタン(subWidgetsの最初の要素)の幅を取得する。
     * 言語設定によってボタン幅が変わる(日本語/中国語は短い文字、英語の"Ignore"は長い)ため、
     * 固定値で決め打ちせずその都度実測することで、どの言語でも重ならないようにする。
     * 取得できなければフォールバック値(28px、日本語想定)を返す。
     */
    private int mattask$getIgnoreButtonWidth() {
        try {
            Field subWidgetsField = mattask$findFieldInHierarchy(this.getClass(), "subWidgets");
            if (subWidgetsField != null) {
                subWidgetsField.setAccessible(true);
                Object subWidgets = subWidgetsField.get(this);
                if (subWidgets instanceof java.util.List<?> list && !list.isEmpty()) {
                    Object existingButton = list.get(0);
                    Integer w = (Integer) mattask$invokeNoArg(existingButton, "getWidth");
                    if (w != null && w > 0) {
                        return w;
                    }
                }
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$getIgnoreButtonWidth failed", e);
        }
        return 28; // フォールバック(日本語/中国語想定)
    }

    /** 指定名・引数型のメソッドを、自クラスから親クラスへ順に遡って探す(protected/private含む)。見つからなければnull。 */
    private Method mattask$findMethodInHierarchy(Class<?> startClass, String name, Class<?>... paramTypes) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredMethod(name, paramTypes);
            } catch (NoSuchMethodException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /**
     * 「今開いてる設計図」を識別するキー(schematicUid代わり)を取得する。
     * 本来はSyncmaticaのセッションUUIDと紐付けたいが、その調査コストが高いため
     * 当面は MaterialListPlacement#getName() (設計図名)を代用する。
     * データ層・通信層はどちらもただの文字列キーとして扱っているため、
     * 将来Syncmaticaの実UUIDに差し替えるのは低コストな想定。
     */
    private String mattask$getSchematicUid() {
        try {
            Field materialListField = mattask$findFieldInHierarchy(this.getClass(), "materialList");
            if (materialListField == null) return null;
            materialListField.setAccessible(true);
            Object materialList = materialListField.get(this);
            if (materialList == null) return null;
            Object name = mattask$invokeNoArg(materialList, "getName");
            return name != null ? name.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$getSchematicUid failed", e);
            return null;
        }
    }

    /** 指定名のフィールドを、自クラスから親クラスへ順に遡って探す。見つからなければnull。 */
    private Field mattask$findFieldInHierarchy(Class<?> startClass, String fieldName) {
        Class<?> current = startClass;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** 引数なしのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeNoArg(Object target, String methodName) {
        try {
            Method m = target.getClass().getMethod(methodName);
            return m.invoke(target);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeNoArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /** 引数1つのpublicメソッド(継承元含む)をリフレクションで呼ぶ。失敗したらnull。 */
    private Object mattask$invokeOneArg(Object target, String methodName, Class<?> argType, Object arg) {
        try {
            Method m = target.getClass().getMethod(methodName, argType);
            return m.invoke(target, arg);
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "invokeOneArg(" + methodName + ") failed", e);
            return null;
        }
    }

    /**
     * MaterialListEntry.item フィールドの可視性が不明(privateかもしれない)なため、
     * 直接アクセスせずリフレクション経由で安全に読む。取得できなければnullを返す。
     */
    private String mattask$readItemKey(Object entry) {
        try {
            Field f = entry.getClass().getDeclaredField("item");
            f.setAccessible(true);
            Object item = f.get(entry);
            return item != null ? item.toString() : null;
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "mattask$readItemKey failed", e);
            return null;
        }
    }

    private void mattask$dumpObject(Object target, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = target.getClass();
            sb.append("=== Field dump for ").append(label).append(" (").append(clazz.getName()).append(") ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(target);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 150) {
                                valueStr = valueStr.substring(0, 150) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }
            sb.append("=== Method dump ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }
            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "dumpObject failed for " + label, e);
        }
    }

    /**
     * Phase 4の設計材料集め用。このウィジェットのクラス階層にある
     * 全フィールド(自分自身のインスタンス値つき)と、全メソッド名/引数の型を
     * 1回だけログに出す。
     */
    private void mattask$dumpStructure() {
        try {
            StringBuilder sb = new StringBuilder();
            Class<?> clazz = this.getClass();

            sb.append("=== Field dump for ").append(clazz.getName()).append(" and superclasses ===\n");
            Class<?> current = clazz;
            while (current != null && current != Object.class) {
                sb.append("-- class: ").append(current.getName()).append(" --\n");
                for (Field f : current.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object value = f.get(this);
                        String valueStr;
                        try {
                            valueStr = String.valueOf(value);
                            if (valueStr.length() > 120) {
                                valueStr = valueStr.substring(0, 120) + "...(truncated)";
                            }
                        } catch (Exception e) {
                            valueStr = "<toString failed: " + e + ">";
                        }
                        sb.append("   field: ").append(f.getType().getSimpleName())
                                .append(" ").append(f.getName())
                                .append(" = ").append(valueStr).append("\n");
                    } catch (Exception e) {
                        sb.append("   field: ").append(f.getName()).append(" (unreadable: ").append(e).append(")\n");
                    }
                }
                current = current.getSuperclass();
            }

            sb.append("=== Method dump (names + param types only) ===\n");
            current = clazz;
            while (current != null && current != Object.class) {
                for (Method m : current.getDeclaredMethods()) {
                    StringBuilder params = new StringBuilder();
                    for (Class<?> p : m.getParameterTypes()) {
                        if (params.length() > 0) params.append(", ");
                        params.append(p.getSimpleName());
                    }
                    sb.append("   method: ").append(m.getReturnType().getSimpleName())
                            .append(" ").append(m.getName())
                            .append("(").append(params).append(")\n");
                }
                current = current.getSuperclass();
            }

            for (String line : sb.toString().split("\n")) {
                MattaskLog.info("WidgetMaterialListEntryDump", line);
            }
        } catch (Exception e) {
            MattaskLog.error("WidgetMaterialListEntryMixin", "structure dump failed", e);
        }
    }
}
