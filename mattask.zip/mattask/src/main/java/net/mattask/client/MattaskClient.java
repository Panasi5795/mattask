package net.mattask.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.mattask.common.MattaskLog;
import net.mattask.common.data.PlayerSnapshot;
import net.mattask.common.network.MattaskPayloads.*;

import java.util.ArrayList;
import java.util.List;

/**
 * クライアント側エントリポイント。
 * Phase 2時点では「サーバーから受け取ったデータをメモリ上に持つだけ」で、
 * 実際のGUI描画(Litematica Material Listへの差し込み)はPhase 3以降、
 * net.mattask.client.mixin.WidgetMaterialListEntryMixin 側で行う。
 */
public class MattaskClient implements ClientModInitializer {
    private static final com.google.gson.Gson GSON = new com.google.gson.Gson();

    /** 直近サーバーから受け取ったプレイヤー一覧のキャッシュ(GUI側から参照する) */
    public static volatile List<PlayerSnapshot> knownPlayers = new ArrayList<>();

    /** 直近同期されたタスク状態(schematicUid -> セッションJSON、後でパースして使う) */
    public static volatile String lastTaskStateJson = null;

    /**
     * Phase 4暫定: itemKey -> 担当プレイヤー名 のクライアントローカルなだけのマップ。
     * まだサーバーと同期していない、見た目確認用の仮実装。
     * Phase 5でサーバー側のMaterialTaskSessionと正式に同期する形に置き換える。
     */
    public static final java.util.Map<String, String> localAssignments = new java.util.concurrent.ConcurrentHashMap<>();

    @Override
    public void onInitializeClient() {
        MattaskLog.info("MattaskClient", "onInitializeClient");

        ClientPlayNetworking.registerGlobalReceiver(PlayerListS2C.ID, (payload, context) -> {
            PlayerSnapshot[] arr = GSON.fromJson(payload.playersJson(), PlayerSnapshot[].class);
            context.client().execute(() -> {
                knownPlayers = List.of(arr);
                MattaskLog.debug("MattaskClient", "received player list, size=" + arr.length);
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(TaskStateSyncS2C.ID, (payload, context) -> {
            context.client().execute(() -> {
                lastTaskStateJson = payload.sessionJson();
                MattaskLog.debug("MattaskClient", "received task state sync");
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(InventoryProgressS2C.ID, (payload, context) -> {
            context.client().execute(() -> {
                MattaskLog.debug("MattaskClient", "received inventory progress for " + payload.uuidStr());
                // TODO(Phase 5): 該当プレイヤーが担当しているItemTaskのautoCollectedCountを更新しGUIへ反映
            });
        });
    }

    /** サーバーへプレイヤー一覧を要求する(Material List画面を開いた時などに呼ぶ想定) */
    public static void requestPlayerList() {
        if (ClientPlayNetworking.canSend(RequestPlayerListC2S.ID)) {
            ClientPlayNetworking.send(new RequestPlayerListC2S());
        }
    }

    public static void sendAssignPlayer(String schematicUid, String itemKey, java.util.UUID uuidOrNull) {
        String uuidStr = uuidOrNull == null ? "" : uuidOrNull.toString();
        if (ClientPlayNetworking.canSend(AssignPlayerC2S.ID)) {
            ClientPlayNetworking.send(new AssignPlayerC2S(schematicUid, itemKey, uuidStr));
        }
    }

    public static void sendSetManualCheck(String schematicUid, String itemKey, boolean checked) {
        if (ClientPlayNetworking.canSend(SetManualCheckC2S.ID)) {
            ClientPlayNetworking.send(new SetManualCheckC2S(schematicUid, itemKey, checked));
        }
    }
}
