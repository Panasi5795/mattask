package net.mattask.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.mattask.common.MattaskLog;
import net.mattask.common.data.ItemTask;
import net.mattask.common.data.MaterialTaskSession;
import net.mattask.common.data.PlayerSnapshot;
import net.mattask.common.network.MattaskPayloads.*;

import java.util.ArrayList;
import java.util.List;

/**
 * クライアント側エントリポイント。
 * Phase 2時点では「サーバーから受け取ったデータをメモリ上に持つだけ」で、
 * 実際のGUI描画(Litematica Material Listへの差し込み)はPhase 3以降、
 * net.mattask.client.mixin.WidgetMaterialListEntryMixin 側で行う。
 */
public class MattaskClient implements ClientModInitializer {
    private static final com.google.gson.Gson GSON = new com.google.gson.Gson();

    /** 直近サーバーから受け取ったプレイヤー一覧のキャッシュ(GUI側から参照する) */
    public static volatile List<PlayerSnapshot> knownPlayers = new ArrayList<>();

    /** 直近同期されたタスク状態(schematicUid -> セッションJSON、後でパースして使う) */
    public static volatile String lastTaskStateJson = null;

    /**
     * itemKey -> 担当プレイヤー名 のクライアントローカルキャッシュ。
     * サーバーからのTaskStateSyncS2Cを受信すると、ここが更新される
     * (UUIDのままだと表示に使いにくいので、knownPlayersと突き合わせて名前に変換して保持する)。
     * GUI(Mixin)側はここを見て表示を更新する。
     */
    public static final java.util.Map<String, String> localAssignments = new java.util.concurrent.ConcurrentHashMap<>();

    @Override
    public void onInitializeClient() {
        MattaskLog.info("MattaskClient", "onInitializeClient");

        ClientPlayNetworking.registerGlobalReceiver(PlayerListS2C.ID, (payload, context) -> {
            PlayerSnapshot[] arr = GSON.fromJson(payload.playersJson(), PlayerSnapshot[].class);
            context.client().execute(() -> {
                knownPlayers = List.of(arr);
                MattaskLog.debug("MattaskClient", "received player list, size=" + arr.length);
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(TaskStateSyncS2C.ID, (payload, context) -> {
            context.client().execute(() -> {
                lastTaskStateJson = payload.sessionJson();
                applyTaskState(payload.sessionJson());
                MattaskLog.debug("MattaskClient", "received task state sync");
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(InventoryProgressS2C.ID, (payload, context) -> {
            context.client().execute(() -> {
                MattaskLog.debug("MattaskClient", "received inventory progress for " + payload.uuidStr());
                // TODO(Phase 5): 該当プレイヤーが担当しているItemTaskのautoCollectedCountを更新しGUIへ反映
            });
        });
    }

    /**
     * サーバーから受け取ったセッションJSONをパースして localAssignments に反映する。
     * assignedPlayer は UUID なので、knownPlayers から名前を逆引きする
     * (見つからない場合はUUIDの先頭部分をそのまま表示に使う、フェイルセーフ)。
     */
    private void applyTaskState(String sessionJson) {
        try {
            MaterialTaskSession session = GSON.fromJson(sessionJson, MaterialTaskSession.class);
            if (session == null || session.items == null) return;

            for (ItemTask item : session.items) {
                if (item.assignedPlayer == null) {
                    localAssignments.remove(item.itemKey);
                    continue;
                }
                String name = null;
                for (PlayerSnapshot p : knownPlayers) {
                    if (p.uuid != null && p.uuid.equals(item.assignedPlayer)) {
                        name = p.name;
                        break;
                    }
                }
                if (name == null) {
                    // knownPlayersにまだ載っていない(取得前など)場合のフェイルセーフ表示
                    name = item.assignedPlayer.toString().substring(0, 8) + "...";
                }
                localAssignments.put(item.itemKey, name);
            }
            MattaskLog.debug("MattaskClient", "applied task state, " + session.items.size() + " items");
        } catch (Exception e) {
            MattaskLog.error("MattaskClient", "failed to apply task state json", e);
        }
    }

    /** サーバーへプレイヤー一覧を要求する(Material List画面を開いた時などに呼ぶ想定) */
    public static void requestPlayerList() {
        if (ClientPlayNetworking.canSend(RequestPlayerListC2S.ID)) {
            ClientPlayNetworking.send(new RequestPlayerListC2S());
        }
    }

    /** サーバーへ現在の割り当て/進捗状況を要求する(Material List画面を開いた時に呼ぶ) */
    public static void requestTaskState(String schematicUid) {
        if (schematicUid == null) return;
        if (ClientPlayNetworking.canSend(RequestTaskStateC2S.ID)) {
            ClientPlayNetworking.send(new RequestTaskStateC2S(schematicUid));
        }
    }

    public static void sendAssignPlayer(String schematicUid, String itemKey, java.util.UUID uuidOrNull) {
        String uuidStr = uuidOrNull == null ? "" : uuidOrNull.toString();
        if (ClientPlayNetworking.canSend(AssignPlayerC2S.ID)) {
            ClientPlayNetworking.send(new AssignPlayerC2S(schematicUid, itemKey, uuidStr));
        }
    }

    public static void sendSetManualCheck(String schematicUid, String itemKey, boolean checked) {
        if (ClientPlayNetworking.canSend(SetManualCheckC2S.ID)) {
            ClientPlayNetworking.send(new SetManualCheckC2S(schematicUid, itemKey, checked));
        }
    }
}
