package net.mattask.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.RollingFileAppender;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.apache.logging.log4j.core.appender.rolling.SizeBasedTriggeringPolicy;
import org.apache.logging.log4j.core.appender.rolling.DefaultRolloverStrategy;

/**
 * 正式リリース前提のデバッグ用ロガー。
 * 通常の latest.log とは別に logs/mattask-debug.log に出力する。
 * config トグル (MattaskConfig.debugLogging 想定, Phase 2以降で実装) で on/off できるようにする。
 *
 * 使い方: MattaskLog.init() をmod初期化時に1回呼ぶ。以後 MattaskLog.debug(...) 等を使う。
 */
public final class MattaskLog {
    public static final String LOGGER_NAME = "mattask-debug";
    private static final Logger STANDARD_LOGGER = LogManager.getLogger("mattask");
    private static Logger debugLogger;
    private static boolean initialized = false;
    private static volatile boolean enabled = true;

    private MattaskLog() {
    }

    /** mod初期化時に1回だけ呼ぶ。専用ファイルAppenderを組み立てる。 */
    public static synchronized void init() {
        if (initialized) {
            return;
        }
        initialized = true;

        try {
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            Configuration config = context.getConfiguration();

            PatternLayout layout = PatternLayout.newBuilder()
                    .withConfiguration(config)
                    .withPattern("[%d{yyyy-MM-dd HH:mm:ss}] [%t] [%-5level] %msg%n")
                    .build();

            // logs/mattask-debug.log, 10MBごとにローテーション, 世代数5で肥大化防止
            RollingFileAppender appender = RollingFileAppender.newBuilder()
                    .setName("MattaskDebugFile")
                    .withFileName("logs/mattask-debug.log")
                    .withFilePattern("logs/mattask-debug-%i.log.gz")
                    .setLayout(layout)
                    .withPolicy(SizeBasedTriggeringPolicy.createPolicy("10MB"))
                    .withStrategy(DefaultRolloverStrategy.newBuilder()
                            .withMax("5")
                            .build())
                    .setConfiguration(config)
                    .build();
            appender.start();
            config.addAppender(appender);

            LoggerConfig loggerConfig = new LoggerConfig(LOGGER_NAME, org.apache.logging.log4j.Level.DEBUG, false);
            loggerConfig.addAppender(appender, null, null);
            config.addLogger(LOGGER_NAME, loggerConfig);

            context.updateLoggers();

            debugLogger = LogManager.getLogger(LOGGER_NAME);
            debugLogger.info("=== MatTask debug logging initialized ===");
        } catch (Exception e) {
            // ここで失敗してもMod本体は動き続けさせる(デバッグログはあくまで補助)
            STANDARD_LOGGER.warn("[mattask] failed to initialize dedicated debug log file, falling back to standard logger", e);
        }
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }

    private static Logger logger() {
        return debugLogger != null ? debugLogger : STANDARD_LOGGER;
    }

    public static void debug(String component, String message) {
        if (!enabled) return;
        logger().debug("[{}] {}", component, message);
    }

    public static void info(String component, String message) {
        if (!enabled) return;
        logger().info("[{}] {}", component, message);
    }

    public static void warn(String component, String message) {
        // 警告は enabled フラグに関わらず常に出す(フェイルセーフ動作の可視化のため)
        logger().warn("[{}] {}", component, message);
    }

    public static void error(String component, String message, Throwable t) {
        logger().error("[{}] {}", component, message, t);
    }
}
