package net.mattask.common.data;

import java.util.UUID;

/**
 * Material List上の1アイテム分の割り当て・進捗状態。
 * itemKey は "minecraft:oak_planks" のような識別子文字列
 * (NBT差分を区別したい場合は末尾にhashを付与する運用を想定、Phase 0残タスク §9-4参照)。
 */
public class ItemTask {
    public String itemKey;
    public int requiredCount;

    /** 未割当なら null */
    public UUID assignedPlayer;

    /** 手動チェック。true なら自動判定を無視して「集まった」扱いにする */
    public boolean manualCollected;

    /** 担当者インベントリから検出した最新の保持数(キャッシュ)。オフライン中は最後の値を維持("凍結") */
    public int autoCollectedCount;

    public ItemTask() {
    }

    public ItemTask(String itemKey, int requiredCount) {
        this.itemKey = itemKey;
        this.requiredCount = requiredCount;
        this.assignedPlayer = null;
        this.manualCollected = false;
        this.autoCollectedCount = 0;
    }

    /** 「集まった」判定 = 手動チェック or 自動検出数が必要数を満たしている */
    public boolean isCollected() {
        return manualCollected || autoCollectedCount >= requiredCount;
    }
}
