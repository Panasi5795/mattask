package net.mattask.common.data;

import java.util.ArrayList;
import java.util.List;

/**
 * 1つのSyncmatica共有設計図(schematicUid = SyncmaticaのServerPlacement UUID文字列)に
 * 対応するタスク割り当て状態全体。これがそのまま
 * world/data/mattask/&lt;schematicUid&gt;.json としてシリアライズされる。
 */
public class MaterialTaskSession {
    public String schematicUid;
    public String schematicName;
    public long lastUpdated;
    public List<ItemTask> items = new ArrayList<>();

    public MaterialTaskSession() {
    }

    public MaterialTaskSession(String schematicUid, String schematicName) {
        this.schematicUid = schematicUid;
        this.schematicName = schematicName;
        this.lastUpdated = System.currentTimeMillis();
    }

    public ItemTask findItem(String itemKey) {
        for (ItemTask item : items) {
            if (item.itemKey.equals(itemKey)) {
                return item;
            }
        }
        return null;
    }

    public ItemTask findOrCreateItem(String itemKey, int requiredCount) {
        ItemTask existing = findItem(itemKey);
        if (existing != null) {
            // 要求数がMaterial List側の再計算で変わることがあるので同期しておく
            existing.requiredCount = requiredCount;
            return existing;
        }
        ItemTask created = new ItemTask(itemKey, requiredCount);
        items.add(created);
        return created;
    }

    public void touch() {
        this.lastUpdated = System.currentTimeMillis();
    }
}
