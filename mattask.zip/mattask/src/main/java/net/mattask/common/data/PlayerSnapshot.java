package net.mattask.common.data;

import java.util.UUID;

/**
 * プルダウンに出すプレイヤー1人分の情報。
 * オンライン/オフライン両方を含む(§5.1)。
 */
public class PlayerSnapshot {
    public UUID uuid;
    public String name;
    public boolean online;

    public PlayerSnapshot() {
    }

    public PlayerSnapshot(UUID uuid, String name, boolean online) {
        this.uuid = uuid;
        this.name = name;
        this.online = online;
    }
}
