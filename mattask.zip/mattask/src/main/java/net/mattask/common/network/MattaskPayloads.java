package net.mattask.common.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * mattask独自のネットワークチャンネル定義。
 *
 * 設計方針(design.md §4参照):
 * LitematicaやServuxが持つ内部の"Data Tag"プロトコルには一切乗らず、
 * 完全に独立したチャンネルとして実装する。
 *
 * 実装方針(シンプルさ優先):
 * 複雑なネストしたデータ(MaterialTaskSession全体や PlayerSnapshotの配列)は、
 * ペイロード側で細かくPacketCodecを組み立てず、Gsonで一旦JSON文字列に変換してから
 * 1つのStringフィールドとして送る。帯域効率はやや落ちるが、
 * 「バージョン間の互換性が壊れにくい・実装がシンプルで保守しやすい」ことを優先した
 * (個人用modなので大量プレイヤー同時使用のスケールは想定していない)。
 */
public final class MattaskPayloads {
    private MattaskPayloads() {
    }

    // ------------------------------------------------------------------
    // C2S: プレイヤー一覧要求 (中身なし)
    // ------------------------------------------------------------------
    public record RequestPlayerListC2S() implements CustomPayload {
        public static final CustomPayload.Id<RequestPlayerListC2S> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "request_player_list"));
        public static final PacketCodec<PacketByteBuf, RequestPlayerListC2S> CODEC =
                PacketCodec.unit(new RequestPlayerListC2S());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // S2C: プレイヤー一覧 (PlayerSnapshotのリストをJSON化したもの)
    // ------------------------------------------------------------------
    public record PlayerListS2C(String playersJson) implements CustomPayload {
        public static final CustomPayload.Id<PlayerListS2C> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "player_list"));
        public static final PacketCodec<PacketByteBuf, PlayerListS2C> CODEC = PacketCodec.of(
                (value, buf) -> buf.writeString(value.playersJson()),
                buf -> new PlayerListS2C(buf.readString(32767))
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // C2S: 担当プレイヤー割り当て変更
    // uuidStr は割り当て解除の場合 "" (空文字) を使う
    // ------------------------------------------------------------------
    public record AssignPlayerC2S(String schematicUid, String itemKey, String uuidStr) implements CustomPayload {
        public static final CustomPayload.Id<AssignPlayerC2S> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "assign_player"));
        public static final PacketCodec<PacketByteBuf, AssignPlayerC2S> CODEC = PacketCodec.of(
                (value, buf) -> {
                    buf.writeString(value.schematicUid());
                    buf.writeString(value.itemKey());
                    buf.writeString(value.uuidStr());
                },
                buf -> new AssignPlayerC2S(buf.readString(256), buf.readString(256), buf.readString(64))
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // C2S: 手動チェック切り替え
    // ------------------------------------------------------------------
    public record SetManualCheckC2S(String schematicUid, String itemKey, boolean checked) implements CustomPayload {
        public static final CustomPayload.Id<SetManualCheckC2S> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "set_manual_check"));
        public static final PacketCodec<PacketByteBuf, SetManualCheckC2S> CODEC = PacketCodec.of(
                (value, buf) -> {
                    buf.writeString(value.schematicUid());
                    buf.writeString(value.itemKey());
                    buf.writeBoolean(value.checked());
                },
                buf -> new SetManualCheckC2S(buf.readString(256), buf.readString(256), buf.readBoolean())
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // S2C: タスク状態全量同期 (MaterialTaskSessionをJSON化したもの)
    // ------------------------------------------------------------------
    public record TaskStateSyncS2C(String sessionJson) implements CustomPayload {
        public static final CustomPayload.Id<TaskStateSyncS2C> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "task_state_sync"));
        public static final PacketCodec<PacketByteBuf, TaskStateSyncS2C> CODEC = PacketCodec.of(
                (value, buf) -> buf.writeString(value.sessionJson()),
                buf -> new TaskStateSyncS2C(buf.readString(32767))
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // C2S: 現在の割り当て/進捗状況を要求する(Material List画面を開いた時に送る)
    // ------------------------------------------------------------------
    public record RequestTaskStateC2S(String schematicUid) implements CustomPayload {
        public static final CustomPayload.Id<RequestTaskStateC2S> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "request_task_state"));
        public static final PacketCodec<PacketByteBuf, RequestTaskStateC2S> CODEC = PacketCodec.of(
                (value, buf) -> buf.writeString(value.schematicUid()),
                buf -> new RequestTaskStateC2S(buf.readString(256))
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    // S2C: インベントリ進捗差分 (対象プレイヤー1人分、itemKey->count のJSON)
    // ------------------------------------------------------------------
    public record InventoryProgressS2C(String uuidStr, String countsJson) implements CustomPayload {
        public static final CustomPayload.Id<InventoryProgressS2C> ID =
                new CustomPayload.Id<>(Identifier.of("mattask", "inventory_progress"));
        public static final PacketCodec<PacketByteBuf, InventoryProgressS2C> CODEC = PacketCodec.of(
                (value, buf) -> {
                    buf.writeString(value.uuidStr());
                    buf.writeString(value.countsJson());
                },
                buf -> new InventoryProgressS2C(buf.readString(64), buf.readString(32767))
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }
}
