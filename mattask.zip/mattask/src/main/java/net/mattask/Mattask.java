package net.mattask;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.mattask.common.MattaskLog;
import net.mattask.common.network.MattaskPayloads.*;
import net.mattask.server.PlayerDirectory;
import net.mattask.server.SyncmaticaPlacementWatcher;
import net.mattask.server.TaskStateStore;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 共通(client+server両方でロードされる)エントリポイント。
 * ネットワークペイロードの型登録はここでまとめて行う
 * (登録自体はclient/serverどちらの環境でも安全に呼べる)。
 */
public class Mattask implements ModInitializer {
    public static final String MOD_ID = "mattask";

    // サーバー側の状態はサーバーインスタンスにぶら下げる場所がないので
    // 素朴にstaticで持つ(1鯖1インスタンス前提。統合サーバー/専用サーバーどちらでも動く)。
    public static final PlayerDirectory PLAYER_DIRECTORY = new PlayerDirectory();
    public static final TaskStateStore TASK_STATE_STORE = new TaskStateStore();
    public static final SyncmaticaPlacementWatcher PLACEMENT_WATCHER = new SyncmaticaPlacementWatcher();

    private static final int PLACEMENT_POLL_INTERVAL_TICKS = 20 * 30; // 30秒毎
    private static final int STATE_FLUSH_INTERVAL_TICKS = 20 * 10;    // 10秒毎
    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        MattaskLog.init();
        MattaskLog.info("Mattask", "onInitialize");

        registerPayloadTypes();
        registerServerPlayHandlers();

        ServerLifecycleEvents.SERVER_STARTED.register(this::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPING.register(this::onServerStopping);
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.getPlayer();
            PLAYER_DIRECTORY.rememberPlayer(player.getUuid(), player.getGameProfile().name());
        });
    }

    private void registerPayloadTypes() {
        PayloadTypeRegistry.playC2S().register(RequestPlayerListC2S.ID, RequestPlayerListC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(AssignPlayerC2S.ID, AssignPlayerC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(SetManualCheckC2S.ID, SetManualCheckC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestTaskStateC2S.ID, RequestTaskStateC2S.CODEC);

        PayloadTypeRegistry.playS2C().register(PlayerListS2C.ID, PlayerListS2C.CODEC);
        PayloadTypeRegistry.playS2C().register(TaskStateSyncS2C.ID, TaskStateSyncS2C.CODEC);
        PayloadTypeRegistry.playS2C().register(InventoryProgressS2C.ID, InventoryProgressS2C.CODEC);

        MattaskLog.debug("Mattask", "network payload types registered");
    }

    private void registerServerPlayHandlers() {
        ServerPlayNetworking.registerGlobalReceiver(RequestPlayerListC2S.ID, (payload, context) -> {
            MinecraftServer server = context.server();
            ServerPlayerEntity player = context.player();
            server.execute(() -> {
                String json = PLAYER_DIRECTORY.buildSnapshotJson(server);
                ServerPlayNetworking.send(player, new PlayerListS2C(json));
                MattaskLog.debug("Network", "sent player list to " + player.getGameProfile().name());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(AssignPlayerC2S.ID, (payload, context) -> {
            MinecraftServer server = context.server();
            server.execute(() -> {
                MattaskLog.debug("Network", "AssignPlayerC2S received: " + payload);
                // Syncmaticaの実UUIDとまだ紐付けていないため、schematicUid(=設計図名)が
                // 未知でもここで自動的にセッション/アイテムを作成する(design.md §7参照、
                // 将来Syncmatica連携を追加する際にgetOrCreateの呼び出し元を差し替える想定)。
                var session = TASK_STATE_STORE.getOrCreate(payload.schematicUid(), payload.schematicUid());
                // requiredCountはこのパケットには乗っていないため暫定的に0で作成する
                // (収集判定機能はまだ実装していないため、現時点では実害なし)。
                var item = session.findOrCreateItem(payload.itemKey(), 0);
                item.assignedPlayer = payload.uuidStr().isEmpty() ? null : java.util.UUID.fromString(payload.uuidStr());
                TASK_STATE_STORE.markDirty(payload.schematicUid());
                MattaskLog.info("Network", "assigned " + payload.itemKey() + " -> " + item.assignedPlayer + " in session " + payload.schematicUid());
                broadcastTaskState(server, payload.schematicUid());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SetManualCheckC2S.ID, (payload, context) -> {
            MinecraftServer server = context.server();
            server.execute(() -> {
                var session = TASK_STATE_STORE.getOrCreate(payload.schematicUid(), payload.schematicUid());
                var item = session.findOrCreateItem(payload.itemKey(), 0);
                item.manualCollected = payload.checked();
                TASK_STATE_STORE.markDirty(payload.schematicUid());
                broadcastTaskState(server, payload.schematicUid());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(RequestTaskStateC2S.ID, (payload, context) -> {
            MinecraftServer server = context.server();
            ServerPlayerEntity player = context.player();
            server.execute(() -> {
                // まだ何も割り当てられていない設計図でも空セッションを返せるよう自動作成する
                TASK_STATE_STORE.getOrCreate(payload.schematicUid(), payload.schematicUid());
                String json = TASK_STATE_STORE.toJson(payload.schematicUid());
                if (json != null) {
                    ServerPlayNetworking.send(player, new TaskStateSyncS2C(json));
                    MattaskLog.debug("Network", "sent task state for " + payload.schematicUid() + " to " + player.getGameProfile().name());
                }
            });
        });
    }

    /** 指定したschematicUidの最新状態を、現在オンラインの全プレイヤーへ送る(誰が見ているかまでは追跡していないので全員へ送る簡易実装) */
    private void broadcastTaskState(MinecraftServer server, String schematicUid) {
        String json = TASK_STATE_STORE.toJson(schematicUid);
        if (json == null) return;
        TaskStateSyncS2C payload = new TaskStateSyncS2C(json);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, payload);
        }
    }

    private void onServerStarted(MinecraftServer server) {
        PLAYER_DIRECTORY.loadFromUserCache(server);
        TASK_STATE_STORE.init(server);
        PLACEMENT_WATCHER.init(server);
        MattaskLog.info("Mattask", "server started, mattask subsystems initialized");
    }

    private void onServerStopping(MinecraftServer server) {
        TASK_STATE_STORE.flushAll();
        MattaskLog.info("Mattask", "server stopping, flushed all task state to disk");
    }

    private void onServerTick(MinecraftServer server) {
        tickCounter++;

        if (tickCounter % PLACEMENT_POLL_INTERVAL_TICKS == 0) {
            var diff = PLACEMENT_WATCHER.pollOnce();
            if (diff != null) {
                for (String uid : diff.added()) {
                    TASK_STATE_STORE.getOrCreate(uid, uid); // 名前はPhase 2以降でSyncmatica側から取得して補完
                }
                for (String uid : diff.removed()) {
                    TASK_STATE_STORE.removeSession(uid);
                }
            }
        }

        if (tickCounter % STATE_FLUSH_INTERVAL_TICKS == 0) {
            TASK_STATE_STORE.flushDirty();
        }

        // TODO(Phase 5): インベントリ監視(design.md §5.2) はここに追加する。
        // 現時点では「割り当てられているアイテムだけ」を対象にした低頻度スキャンは未実装。
    }
}
