package net.mattask.server;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.mattask.common.MattaskLog;
import net.mattask.common.data.PlayerSnapshot;
import net.minecraft.server.MinecraftServer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * 「鯖に来たことがある全員」+オンラインプレイヤーの一覧を管理する(design.md §5.1)。
 *
 * usercache.json はMojang由来のキャッシュファイルで、サーバールート直下に生成される。
 * 形式: [{"name":"...","uuid":"...","expiresOn":"..."}, ...]
 *
 * 注意: usercache.jsonのスキーマもマイナーチェンジの可能性があるため、
 * パース失敗時は例外を投げず「今回はオフライン一覧なし」に劣化させる(フェイルセーフ)。
 */
public class PlayerDirectory {
    private static final String COMPONENT = "PlayerDirectory";
    private final Gson gson = new Gson();

    /** name -> uuid のキャッシュ。起動時に読み込み、以後は差分更新のみ行う想定。 */
    private final Map<String, UUID> offlineKnownPlayers = new LinkedHashMap<>();

    public void loadFromUserCache(MinecraftServer server) {
        Path path = server.getRunDirectory().resolve("usercache.json");
        if (!Files.exists(path)) {
            MattaskLog.warn(COMPONENT, "usercache.json not found at " + path + " (offline player list will be empty until players join)");
            return;
        }

        try {
            String content = Files.readString(path);
            JsonElement root = JsonParser.parseString(content);
            if (!root.isJsonArray()) {
                MattaskLog.warn(COMPONENT, "usercache.json did not parse as a JSON array; skipping offline player load");
                return;
            }
            JsonArray array = root.getAsJsonArray();
            int loaded = 0;
            for (JsonElement el : array) {
                try {
                    if (!el.isJsonObject()) continue;
                    var obj = el.getAsJsonObject();
                    if (!obj.has("name") || !obj.has("uuid")) continue;
                    String name = obj.get("name").getAsString();
                    UUID uuid = UUID.fromString(obj.get("uuid").getAsString());
                    offlineKnownPlayers.put(name, uuid);
                    loaded++;
                } catch (Exception innerEx) {
                    // 1エントリのパース失敗は無視して続行する(全体を諦めない)
                    MattaskLog.warn(COMPONENT, "skipped one malformed usercache entry: " + innerEx.getMessage());
                }
            }
            MattaskLog.info(COMPONENT, "loaded " + loaded + " known players from usercache.json");
        } catch (IOException e) {
            MattaskLog.error(COMPONENT, "failed to read usercache.json", e);
        } catch (Exception e) {
            // スキーマが将来変わってパース自体が例外を吐くケースへの保険
            MattaskLog.error(COMPONENT, "failed to parse usercache.json (schema may have changed)", e);
        }
    }

    /** 新規ログイン時に呼ぶ。usercache全体の再読み込みはしない軽量更新。 */
    public void rememberPlayer(UUID uuid, String name) {
        offlineKnownPlayers.put(name, uuid);
    }

    public List<PlayerSnapshot> buildSnapshot(MinecraftServer server) {
        List<PlayerSnapshot> result = new ArrayList<>();
        Set<UUID> onlineUuids = new HashSet<>();

        server.getPlayerManager().getPlayerList().forEach(p -> {
            onlineUuids.add(p.getUuid());
            result.add(new PlayerSnapshot(p.getUuid(), p.getGameProfile().name(), true));
        });

        for (Map.Entry<String, UUID> entry : offlineKnownPlayers.entrySet()) {
            if (!onlineUuids.contains(entry.getValue())) {
                result.add(new PlayerSnapshot(entry.getValue(), entry.getKey(), false));
            }
        }

        return result;
    }

    public String buildSnapshotJson(MinecraftServer server) {
        return gson.toJson(buildSnapshot(server));
    }
}
