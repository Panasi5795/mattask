package net.mattask.server;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.mattask.common.MattaskLog;
import net.mattask.common.data.MaterialTaskSession;
import net.minecraft.server.MinecraftServer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * design.md §7 の永続化設計に対応。
 * 保存先: world/data/mattask/&lt;schematicUid&gt;.json (1設計図=1ファイル)
 *
 * - 変更はダーティフラグで持って低頻度でまとめて書き込む
 * - Syncmaticaのplacements.jsonから消えたUUIDのファイルは削除する(§11.3)
 */
public class TaskStateStore {
    private static final String COMPONENT = "TaskStateStore";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private final Map<String, MaterialTaskSession> sessions = new ConcurrentHashMap<>();
    private final Set<String> dirtyUids = ConcurrentHashMap.newKeySet();

    private Path dataDir;

    public void init(MinecraftServer server) {
        dataDir = server.getSavePath(net.minecraft.util.WorldSavePath.ROOT).resolve("data").resolve("mattask");
        try {
            Files.createDirectories(dataDir);
        } catch (IOException e) {
            MattaskLog.error(COMPONENT, "failed to create data directory " + dataDir, e);
            return;
        }
        loadAll();
    }

    private void loadAll() {
        if (dataDir == null || !Files.isDirectory(dataDir)) return;
        try (var stream = Files.list(dataDir)) {
            stream.filter(p -> p.toString().endsWith(".json")).forEach(this::loadOne);
        } catch (IOException e) {
            MattaskLog.error(COMPONENT, "failed to list data directory", e);
        }
    }

    private void loadOne(Path path) {
        try {
            String json = Files.readString(path);
            MaterialTaskSession session = gson.fromJson(json, MaterialTaskSession.class);
            if (session != null && session.schematicUid != null) {
                sessions.put(session.schematicUid, session);
                MattaskLog.debug(COMPONENT, "loaded session " + session.schematicUid + " from " + path.getFileName());
            }
        } catch (Exception e) {
            // 1ファイルの読み込み失敗はそのファイルだけ無視して続行(フェイルセーフ)
            MattaskLog.warn(COMPONENT, "failed to load " + path.getFileName() + ", skipping: " + e.getMessage());
        }
    }

    public MaterialTaskSession getOrCreate(String schematicUid, String schematicName) {
        return sessions.computeIfAbsent(schematicUid, uid -> {
            MattaskLog.info(COMPONENT, "creating new task session for " + uid + " (" + schematicName + ")");
            return new MaterialTaskSession(uid, schematicName);
        });
    }

    public MaterialTaskSession get(String schematicUid) {
        return sessions.get(schematicUid);
    }

    public void markDirty(String schematicUid) {
        dirtyUids.add(schematicUid);
    }

    /** 低頻度ループ(例: 10秒毎)から呼ぶ。ダーティなセッションだけファイルへ書き出す。 */
    public void flushDirty() {
        if (dirtyUids.isEmpty()) return;
        for (String uid : Set.copyOf(dirtyUids)) {
            dirtyUids.remove(uid);
            MaterialTaskSession session = sessions.get(uid);
            if (session != null) {
                writeToDisk(session);
            }
        }
    }

    /** シャットダウン時に強制的に全部書き出す */
    public void flushAll() {
        for (MaterialTaskSession session : sessions.values()) {
            writeToDisk(session);
        }
        dirtyUids.clear();
    }

    private void writeToDisk(MaterialTaskSession session) {
        if (dataDir == null) return;
        Path target = dataDir.resolve(session.schematicUid + ".json");
        Path tmp = dataDir.resolve(session.schematicUid + ".json.tmp");
        try {
            session.touch();
            Files.writeString(tmp, gson.toJson(session));
            Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            MattaskLog.debug(COMPONENT, "saved session " + session.schematicUid);
        } catch (IOException e) {
            MattaskLog.error(COMPONENT, "failed to save session " + session.schematicUid, e);
        }
    }

    /**
     * Syncmatica側で共有解除されて消えたUUID群に対応するファイルを削除する。
     * 呼び出し元: SyncmaticaPlacementWatcher (§11.3)
     */
    public void removeSession(String schematicUid) {
        sessions.remove(schematicUid);
        dirtyUids.remove(schematicUid);
        if (dataDir == null) return;
        Path target = dataDir.resolve(schematicUid + ".json");
        try {
            boolean deleted = Files.deleteIfExists(target);
            if (deleted) {
                MattaskLog.info(COMPONENT, "deleted session file for " + schematicUid + " (schematic no longer shared)");
            }
        } catch (IOException e) {
            MattaskLog.error(COMPONENT, "failed to delete session file for " + schematicUid, e);
        }
    }

    public Map<String, MaterialTaskSession> getAll() {
        return new LinkedHashMap<>(sessions);
    }
}
