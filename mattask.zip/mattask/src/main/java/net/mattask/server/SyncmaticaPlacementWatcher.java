package net.mattask.server;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.mattask.common.MattaskLog;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/**
 * design.md §11.3 で確定した疎結合方式:
 * Syncmatica内部クラスにMixinで食いつくのではなく、
 * Syncmaticaがサーバー側で永続化している {worldFolder}/syncmatica/placements.json を
 * 定期的にポーリングして「現在共有中の設計図UUID一覧」を検知する。
 *
 * !!! 要検証 !!!
 * placements.json の実際のJSONスキーマ(キーの名前、配列かオブジェクトか等)は
 * DeepWiki経由の調査では「SyncmaticManagerがUUIDキーのHashMapをatomic writeしている」
 * という設計方針しか確認できていない。実際のファイルを1つ用意してこのクラスの
 * parseKnownUuids() を実物に合わせて調整すること(Phase 0残タスク)。
 * パースに失敗しても例外を投げず「今回は更新なし」に劣化させる設計にしてある。
 */
public class SyncmaticaPlacementWatcher {
    private static final String COMPONENT = "SyncmaticaPlacementWatcher";

    private Path placementsFile;
    private Set<String> lastKnownUuids = new HashSet<>();

    public void init(MinecraftServer server) {
        Path worldRoot = server.getSavePath(WorldSavePath.ROOT);
        this.placementsFile = worldRoot.resolve("syncmatica").resolve("placements.json");
        MattaskLog.info(COMPONENT, "watching " + placementsFile);
    }

    /**
     * @return 変更があった場合のみ非nullで {added, removed} を返す。変更なしはnull。
     */
    public Diff pollOnce() {
        if (placementsFile == null || !Files.exists(placementsFile)) {
            return null;
        }

        Set<String> current;
        try {
            String content = Files.readString(placementsFile);
            current = parseKnownUuids(content);
        } catch (IOException e) {
            MattaskLog.warn(COMPONENT, "failed to read placements.json (will retry next poll): " + e.getMessage());
            return null;
        } catch (Exception e) {
            MattaskLog.warn(COMPONENT, "failed to parse placements.json, schema may differ from expected (will retry next poll): " + e.getMessage());
            return null;
        }

        if (current.equals(lastKnownUuids)) {
            return null;
        }

        Set<String> added = new HashSet<>(current);
        added.removeAll(lastKnownUuids);
        Set<String> removed = new HashSet<>(lastKnownUuids);
        removed.removeAll(current);

        lastKnownUuids = current;

        if (!added.isEmpty()) {
            MattaskLog.info(COMPONENT, "new shared schematics detected: " + added);
        }
        if (!removed.isEmpty()) {
            MattaskLog.info(COMPONENT, "shared schematics removed: " + removed);
        }

        return new Diff(added, removed);
    }

    /**
     * 想定パターン1: {"<uuid>": {...}, "<uuid>": {...}} というオブジェクト形式
     * 想定パターン2: [{"uuid": "..."} , ...] または [{"id": "..."}, ...] という配列形式
     * どちらでもないと判断したら空集合を返し、警告ログだけ出す。
     */
    private Set<String> parseKnownUuids(String content) {
        Set<String> uuids = new HashSet<>();

        if (content == null || content.isBlank()) {
            // ファイルはあるがまだ何も共有されていない状態。正常なので警告は出さない。
            return uuids;
        }

        JsonElement root = JsonParser.parseString(content);

        if (root == null || root.isJsonNull()) {
            // 中身が null / 空オブジェクト相当。まだ何も共有されていない状態として扱う。
            return uuids;
        }

        if (root.isJsonObject()) {
            JsonObject obj = root.getAsJsonObject();
            for (String key : obj.keySet()) {
                if (looksLikeUuid(key)) {
                    uuids.add(key);
                }
            }
            // 空オブジェクト({})や、UUID以外のキーしかない設定用オブジェクトも
            // 「まだ何も共有されていない/UUID形式ではなかった」として正常扱いする。
            return uuids;
        }

        if (root.isJsonArray()) {
            for (JsonElement el : root.getAsJsonArray()) {
                if (!el.isJsonObject()) continue;
                JsonObject obj = el.getAsJsonObject();
                for (String field : new String[]{"uuid", "id", "placementId"}) {
                    if (obj.has(field)) {
                        String v = obj.get(field).getAsString();
                        if (looksLikeUuid(v)) {
                            uuids.add(v);
                        }
                        break;
                    }
                }
            }
            return uuids;
        }

        MattaskLog.warn(COMPONENT, "placements.json root is neither a recognizable object nor array; treating as empty");
        return uuids;
    }

    private boolean looksLikeUuid(String s) {
        try {
            java.util.UUID.fromString(s);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    public record Diff(Set<String> added, Set<String> removed) {
    }
}
